-- phpMyAdmin SQL Dump
-- version 4.4.6
-- http://www.phpmyadmin.net
--
-- Host: oracleexpertscebu.com
-- Generation Time: Oct 01, 2015 at 06:11 PM
-- Server version: 5.5.42-cll-lve
-- PHP Version: 5.4.16

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `zsi_sims`
--

DELIMITER $$
--
-- Procedures
--
$$

CREATE DEFINER=`zsi`@`%` PROCEDURE `delPC_Unposted`(IN p_loc_pc_id int(5))
BEGIN
   DELETE FROM loc_pc_dtls WHERE loc_pc_id = p_loc_pc_id;
   DELETE FROM loc_pc WHERE loc_pc_id = p_loc_pc_id;
END$$

CREATE DEFINER=`zsi`@`%` PROCEDURE `delPO_Unposted`(IN p_po_id int(5))
BEGIN
	DELETE FROM po_dtl WHERE po_id = po_id;
	DELETE FROM po WHERE po_id = p_po_id;
END$$

$$

CREATE DEFINER=`zsi`@`%` PROCEDURE `getDesc`(IN p_table VARCHAR(20), IN p_column VARCHAR(20), IN p_where VARCHAR(100))
BEGIN
    SET @sql=CONCAT("SELECT ", p_column, " FROM ", p_table, " ", p_where);
    PREPARE s1 FROM  @sql;
    execute s1;
    DEALLOCATE PREPARE s1;
END$$

$$

$$

CREATE DEFINER=`zsi`@`%` PROCEDURE `getLocPC_Unposted`(p_loc_id int(5))
BEGIN
select * from loc_pc where posted=0
and loc_id=p_loc_id;
END$$

$$

$$

$$

CREATE DEFINER=`zsi`@`%` PROCEDURE `getStoreDailyCash`(p_store_loc_id INT(10),p_date VARCHAR(20))
BEGIN
     SELECT *, getEmplName(empl_id) as empl_name, getEvent(event_id) as event_desc
       FROM store_daily_cash 
      WHERE store_loc_id =p_store_loc_id
        AND tran_date = str_to_date(p_date,'%m/%d/%Y');
END$$

CREATE DEFINER=`zsi`@`%` PROCEDURE `getStoreDailyCashById`(IN p_store_daily_cash_id INT(10))
BEGIN
     SELECT *, getEmplName(empl_id), getEvent(event_id) FROM store_daily_cash WHERE store_daily_cash_id =p_store_daily_cash_id;
END$$

CREATE DEFINER=`zsi`@`%` PROCEDURE `getStoreLocSupplies`(IN p_store_loc_id INT)
BEGIN
     SELECT * FROM store_loc_supplies_v WHERE store_loc_id =p_store_loc_id;
END$$

CREATE DEFINER=`zsi`@`%` PROCEDURE `getStoreLocSupplyDaily`(p_store_loc_id int(5), p_date VARCHAR(20))
BEGIN
select * from store_loc_supply_daily_v where store_loc_id = p_store_loc_id
and DATE_FORMAT(stock_date,'%m/%d/%Y') = p_date; 
END$$

$$

CREATE DEFINER=`zsi`@`%` PROCEDURE `getSupplyIsUnposted`(IN p_store_loc_id int, IN p_loc_supply_id int)
BEGIN
   DECLARE l_id INT(5);
   SELECT supply_is_id INTO l_id FROM supply_is WHERE posted=0 and store_loc_id = p_store_loc_id limit 1;
   IF IFNULL(l_id,0)=0 THEN
      SELECT *, "" as supply_is_id, "" as supply_is_dtl_id, "" as supply_is_qty FROM loc_supply_brands_v WHERE loc_id = getLocIdFromStoreLoc(p_store_loc_id) and loc_supply_id =p_loc_supply_id and stock_qty > 0 ;
   ELSE
    SELECT a.supply_is_id, a.supply_is_dtl_id, b.loc_supply_id,  a.loc_supply_brand_id, b.stock_qty, b.brand_name, b.cu_desc, a.supply_is_qty
       FROM supply_is_dtls a, loc_supply_brands_v b
       WHERE a.loc_supply_brand_id = b.loc_supply_brand_id and a.supply_is_id = l_id
       AND b.loc_supply_id =p_loc_supply_id
      UNION
      SELECT "" as supply_is_id, "" as supply_is_dtl_id, a.loc_supply_id, a.loc_supply_brand_id, a.stock_qty, a.brand_name, a.cu_desc, "" as supply_is_qty 
        FROM loc_supply_brands_v a 
       WHERE a.stock_qty > 0 AND a.loc_supply_id = p_loc_supply_id AND NOT EXISTS (SELECT b.loc_supply_brand_id FROM supply_is_dtls b 
       WHERE b.loc_supply_brand_id = b.loc_supply_brand_id and supply_is_id = l_id);   
   END IF;   
END$$

$$

CREATE DEFINER=`zsi`@`%` PROCEDURE `LocSupplyBrandsIns`(p_loc_id int(5))
BEGIN
INSERT INTO loc_supply_brands (supply_brand_id, loc_supply_id)
SELECT a.supply_brand_id, getLocSupplyId(p_loc_id, a.supply_id) 
FROM supply_brands a
WHERE NOT EXISTS (SELECT supply_brand_id FROM loc_supply_brands b WHERE b.loc_supply_id =  getLocSupplyId(p_loc_id, a.supply_id));
END$$

CREATE DEFINER=`zsi`@`%` PROCEDURE `LocSupplyBrandsIns2`(p_supply_id int(5))
BEGIN
DECLARE l_loc_id   int;
DECLARE l_loc_supply_id INT;
DECLARE exit_loop BOOLEAN;       
DECLARE loc_cursor CURSOR FOR
  SELECT loc_id FROM locations;
 
DECLARE CONTINUE HANDLER FOR NOT FOUND SET exit_loop = TRUE; 
OPEN loc_cursor;  
locations_loop: LOOP 
FETCH  loc_cursor INTO l_loc_id;
     SELECT loc_supply_id INTO l_loc_supply_id FROM loc_supplies WHERE loc_id = l_loc_id AND supply_id = p_supply_id;

     INSERT INTO loc_supply_brands (supply_brand_id, loc_supply_id)
     SELECT a.supply_brand_id, l_loc_supply_id
     FROM supply_brands a
     WHERE a.supply_id = p_supply_id
     AND NOT EXISTS (SELECT supply_brand_id FROM loc_supply_brands_v b WHERE a.supply_brand_id = b.supply_brand_id and b.loc_id=l_loc_id);
     IF exit_loop THEN
         CLOSE loc_cursor;
         LEAVE locations_loop;
     END IF;
   END LOOP locations_loop;

END$$

CREATE DEFINER=`zsi`@`%` PROCEDURE `loc_pc_post`(p_loc_pc_id int(5), p_date varchar(20))
BEGIN
DECLARE l_found VARCHAR(5);
      UPDATE loc_supply_brands a, loc_pc_dtls b 
      SET a.stock_qty = b.pc_qty
      WHERE a.loc_supply_brand_id = b.loc_supply_brand_id
      AND b.loc_pc_id = p_loc_pc_id;    
END$$

$$

$$

$$

$$

$$

$$

$$

$$

CREATE DEFINER=`zsi`@`%` PROCEDURE `setLocStockIsPost`(IN p_supply_is_id INT)
BEGIN
  UPDATE loc_supply_brands a, supply_is_dtls b
  SET a.stock_qty = a.stock_qty - b.supply_is_qty
  WHERE a.loc_supply_brand_id = b.loc_supply_brand_id
  AND b.supply_is_id = p_supply_is_id;
END$$

$$

$$

CREATE DEFINER=`zsi`@`%` PROCEDURE `setStoreDailyExpPosted`(p_store_loc_exp_id int(5), p_store_loc_id int(5), p_exp_date varchar(20))
BEGIN
  DECLARE l_date DATE;
  SET l_date = str_to_date(p_exp_date,'%m/%d/%Y');
  
  UPDATE store_daily_cash
  SET ttl_exp_amt = getExpenseSum(p_store_loc_id,l_date)
     ,ttl_sales_exp_amt =  getSalesExpenseSum(p_store_loc_id,l_date)
  WHERE store_loc_id=p_store_loc_id
    AND tran_date = l_date;
END$$

$$

$$

$$

CREATE DEFINER=`zsi`@`%` PROCEDURE `stock_transfer_post`(p_st_id int(5), p_loc_id_to int)
BEGIN
   UPDATE loc_supply_brands a, stock_transfer_dtls b
   SET a.stock_qty = a.stock_qty - b.st_qty
   WHERE st_id = p_st_id
   AND a.loc_supply_brand_id=b.loc_supply_brand_id;

   UPDATE loc_supply_brands_v a, stock_transfer_dtls b
   SET a.stock_qty = a.stock_qty + b.st_qty
   WHERE st_id = p_st_id
   AND a.supply_brand_id=getSupplyBrandIdFromLoc(b.loc_supply_brand_id)
   AND a.loc_id = p_loc_id_to;
END$$

CREATE DEFINER=`zsi`@`%` PROCEDURE `store_daily_cash_postedCB`(IN p_store_daily_cash_id int(5))
BEGIN
DECLARE l_cash_amt decimal(7,2);
DECLARE l_depo_amt decimal(7,2);
DECLARE l_fr_store_daily_cash_id INT;
DECLARE l_created_by INT;
DECLARE l_created_date DATE;
DECLARE l_store_bank_depo_id INT;

SELECT sum(IFNULL(cash_amount,0))
  INTO l_cash_amt
  FROM store_daily_cash_dtls 
 WHERE store_daily_cash_id=p_store_daily_cash_id;

UPDATE store_daily_cash 
   SET ttl_cash_box_amt   = l_cash_amt
 WHERE store_daily_cash_id=p_store_daily_cash_id;    

SELECT fr_store_daily_cash_id INTO l_fr_store_daily_cash_id
  FROM store_daily_cash 
 WHERE store_daily_cash_id=p_store_daily_cash_id;    

IF IFNULL(l_fr_store_daily_cash_id,0) <> 0 THEN

   SELECT depo_amt, created_by, created_date
     INTO l_depo_amt, l_created_by, l_created_date
     FROM store_daily_cash
    WHERE fr_store_daily_cash_id=l_fr_store_daily_cash_id;

   UPDATE store_daily_cash 
      SET depo_amt = ttl_return_amt - (l_cash_amt + IFNULL(ttl_exp_amt,0))
    WHERE fr_store_daily_cash_id=p_store_daily_cash_id;

   SELECT IFNULL(store_bank_depo_id,0) 
     INTO l_store_bank_depo_id
     FROM store_bank_depo        
    WHERE store_daily_cash_id=l_fr_store_daily_cash_id;    

   IF IFNULL(l_store_bank_depo_id,0)=0 THEN
      INSERT INTO store_bank_depo       
           (store_loc_id, sales_date, depo_amt, created_by, created_date) 
            SELECT store_loc_id, tran_date, depo_amt, created_by, created_date 
              FROM store_daily_cash    
             WHERE store_daily_cash_id=l_fr_store_daily_cash_id;   
   ELSE
      UPDATE store_bank_depo
         SET depo_amt= l_depo_amt,
             created_by=l_created_date,
             created_date=l_created_date
       WHERE store_bank_depo_id = l_store_bank_depo_id;

      DELETE FROM store_bank_depo_dtls WHERE store_bank_depo_id = l_store_bank_depo_id; 
   END IF;
END IF;
   UPDATE store_daily_cash a, store_loc b
      SET a.fr_store_daily_cash_id = b.last_posted_dcash
    WHERE a.store_loc_id = b.store_loc_id
      AND a.store_daily_cash_id=p_store_daily_cash_id;     
END$$

$$

CREATE DEFINER=`zsi`@`%` PROCEDURE `store_daily_cash_report`(p_store_loc_id int, p_tran_date varchar(20))
BEGIN
   SELECT *, get_store_daily_cash_denom_nextday_qty(store_daily_cash_id, denomination) as today_qty
   FROM store_daily_cash_dtls_v
   WHERE store_loc_id = p_store_loc_id AND tran_date = str_to_date(p_tran_date,'%m/%d/%Y');
END$$

CREATE DEFINER=`zsi`@`%` PROCEDURE `store_loc_exp_report`(p_store_loc_id int, p_tran_date varchar(20))
BEGIN
   SELECT *
   FROM store_loc_exp_dtls_v 
   WHERE store_loc_id = p_store_loc_id AND exp_date = str_to_date(p_tran_date,'%m/%d/%Y');
END$$

CREATE DEFINER=`zsi`@`%` PROCEDURE `store_loc_sales_exp_report`(p_store_loc_id int, p_tran_date varchar(20))
BEGIN
   SELECT *
   FROM store_loc_sales_exp_dtls_v 
   WHERE store_loc_id = p_store_loc_id AND exp_date = str_to_date(p_tran_date,'%m/%d/%Y');
END$$

$$

--
-- Functions
--
CREATE DEFINER=`zsi`@`%` FUNCTION `getBankName`(p_bank_ref_id int(5)) RETURNS varchar(100) CHARSET latin1
    DETERMINISTIC
BEGIN
    DECLARE lvl VARCHAR(100);
    SELECT bank_name INTO lvl FROM bank_ref WHERE bank_ref_id = p_bank_ref_id;
 RETURN (ifnull(lvl,''));
END$$

$$

$$

CREATE DEFINER=`zsi`@`%` FUNCTION `getExpenseSum`(p_store_loc_id int(5), p_date date) RETURNS decimal(7,2)
    DETERMINISTIC
BEGIN
 DECLARE lvl decimal(7,2);
    select SUM(exp_amt) INTO lvl from store_loc_exp_dtls_v where store_loc_id = p_store_loc_id
    and exp_date = p_date; 
 RETURN (ifnull(lvl,0));
END$$

CREATE DEFINER=`zsi`@`%` FUNCTION `getlatestrevid`(p_filename varchar(100)) RETURNS varchar(100) CHARSET latin1
    DETERMINISTIC
begin
   declare lvl varchar(100);
   select revision_id into lvl
   from revision_logs
   where filename=p_filename
   order by revision_id desc limit 1;
   return (lvl);
 end$$

CREATE DEFINER=`zsi`@`%` FUNCTION `getLocation`(p_loc_id int) RETURNS varchar(100) CHARSET latin1
    DETERMINISTIC
BEGIN
    DECLARE lvl varchar(100);
    SELECT location INTO lvl FROM locations WHERE loc_id=p_loc_id;
 RETURN (lvl);
END$$

$$

CREATE DEFINER=`zsi`@`%` FUNCTION `getLocIdFromStoreLoc`(p_store_loc_id int) RETURNS varchar(100) CHARSET latin1
    DETERMINISTIC
BEGIN
    DECLARE lvl int(5);
    SELECT loc_id INTO lvl FROM store_loc WHERE store_loc_id=p_store_loc_id;
 RETURN (lvl);
END$$

$$

CREATE DEFINER=`zsi`@`%` FUNCTION `getLocSupplyBrandId`(p_loc_id int, p_supply_id int, p_supply_brand_id int) RETURNS int(5)
    DETERMINISTIC
BEGIN
    DECLARE lvl int;
    SELECT loc_supply_brand_id INTO lvl FROM loc_supply_brands WHERE supply_brand_id=p_supply_brand_id 
       AND loc_supply_id=(select loc_supply_id FROM loc_supplies WHERE loc_id = p_loc_id and supply_id = p_supply_id); 
 RETURN (ifnull(lvl,0));
END$$

$$

CREATE DEFINER=`zsi`@`%` FUNCTION `getLocSupplyId`(p_loc_id int, p_supply_id int) RETURNS int(5)
    DETERMINISTIC
BEGIN
    DECLARE lvl int;
    SELECT loc_supply_id INTO lvl FROM loc_supplies WHERE loc_id = p_loc_id and supply_id = p_supply_id; 
 RETURN (ifnull(lvl,0));
END$$

$$

$$

CREATE DEFINER=`zsi`@`%` FUNCTION `getMenuType`(p_menu_type_id int) RETURNS varchar(100) CHARSET latin1
    DETERMINISTIC
BEGIN
    DECLARE lvl varchar(100);
    SELECT menu_type INTO lvl FROM menu_types WHERE menu_type_id=p_menu_type_id;
 RETURN (lvl);
END$$

CREATE DEFINER=`zsi`@`%` FUNCTION `getPOBalCount`(p_po_id int) RETURNS int(5)
    DETERMINISTIC
BEGIN
    DECLARE lvl int(5);
    SELECT COUNT(po_id) INTO lvl FROM po_dtls WHERE po_id=p_po_id and ifnull(bal_qty,0) > 0 ;
 RETURN (lvl);
END$$

$$

CREATE DEFINER=`zsi`@`%` FUNCTION `getPOLocId`(p_po_id int) RETURNS int(5)
    DETERMINISTIC
BEGIN
    DECLARE lvl varchar(100);
    SELECT loc_id INTO lvl FROM po WHERE po_id=p_po_id;
 RETURN (lvl);
END$$

CREATE DEFINER=`zsi`@`%` FUNCTION `getSalesExpenseSum`(p_store_loc_id int(5), p_date date) RETURNS decimal(7,2)
    DETERMINISTIC
BEGIN
 DECLARE lvl decimal(7,2);
    select SUM(exp_amt) INTO lvl from store_loc_sales_exp_dtls_v where store_loc_id = p_store_loc_id
    and exp_date = p_date; 
 RETURN (ifnull(lvl,0));
END$$

$$

CREATE DEFINER=`zsi`@`%` FUNCTION `getStockCount`(p_loc_supply_id int) RETURNS decimal(7,2)
    DETERMINISTIC
BEGIN
    DECLARE lvl decimal(7,2);
    SELECT sum(stock_qty) INTO lvl FROM loc_supply_brands WHERE loc_supply_id=p_loc_supply_id;
 RETURN (lvl);
END$$

$$

$$

$$

$$

$$

$$

$$

$$

$$

$$

$$

$$

CREATE DEFINER=`zsi`@`%` FUNCTION `getStoreLocSupplyBrandStockQty`(p_store_loc_id INT, p_loc_supply_brand_id INT) RETURNS decimal(7,2)
    DETERMINISTIC
BEGIN
    DECLARE lvl DECIMAL(7,2);
    SELECT stock_qty INTO lvl FROM store_loc_supply_brands_v WHERE store_loc_id = p_store_loc_id and loc_supply_brand_id = p_loc_supply_brand_id; 
 RETURN (ifnull(lvl,0));
END$$

$$

CREATE DEFINER=`zsi`@`%` FUNCTION `getStoreLocSupplyId`(p_store_loc_id int, p_loc_supply_id int) RETURNS int(5)
    DETERMINISTIC
BEGIN
    DECLARE lvl int(5);
    SELECT store_loc_supply_id INTO lvl FROM store_loc_supplies WHERE store_loc_id=p_store_loc_id and loc_supply_id=p_loc_supply_id;
 RETURN (lvl);
END$$

CREATE DEFINER=`zsi`@`%` FUNCTION `getStoreLocTotalStocks`(p_store_loc_supply_id int) RETURNS decimal(7,2)
    DETERMINISTIC
BEGIN
    DECLARE lvl decimal(7,2);
    SELECT ttl_stocks INTO lvl FROM StoreLocSupplyBrandsSum_v WHERE store_loc_supply_id=p_store_loc_supply_id;
 RETURN (ifnull(lvl,0));
END$$

CREATE DEFINER=`zsi`@`%` FUNCTION `getSupplier`(p_supplier_id int) RETURNS varchar(100) CHARSET latin1
    DETERMINISTIC
BEGIN
    DECLARE lvl varchar(100);
    SELECT supplier_name INTO lvl FROM suppliers WHERE supplier_id=p_supplier_id;
 RETURN (lvl);
END$$

CREATE DEFINER=`zsi`@`%` FUNCTION `getSupplierByStore`(p_store_id int) RETURNS varchar(100) CHARSET latin1
    DETERMINISTIC
BEGIN
    DECLARE lvl varchar(100);
    SELECT getSupplier(supplier_id) as supplier_name INTO lvl FROM stores WHERE store_id=store_id;
 RETURN (lvl);
END$$

CREATE DEFINER=`zsi`@`%` FUNCTION `getSupplierIdByStore`(p_store_id int) RETURNS int(5)
    DETERMINISTIC
BEGIN
    DECLARE lvl INT(5);
    SELECT supplier_id as supplier_name INTO lvl FROM stores WHERE store_id=p_store_id;
 RETURN (lvl);
END$$

CREATE DEFINER=`zsi`@`%` FUNCTION `getSupplyBrandIdFromLoc`(p_loc_supply_brand_id int) RETURNS int(5)
    DETERMINISTIC
BEGIN
    DECLARE lvl int;
    SELECT supply_brand_id INTO lvl FROM loc_supply_brands_v WHERE loc_supply_brand_id=p_loc_supply_brand_id;
 RETURN (ifnull(lvl,0));
END$$

$$

CREATE DEFINER=`zsi`@`%` FUNCTION `getSupplyIdFromLoc`(p_loc_supply_id int) RETURNS int(5)
    DETERMINISTIC
BEGIN
    DECLARE lvl int;
    SELECT supply_id INTO lvl FROM loc_supplies WHERE loc_supply_id = p_loc_supply_id; 
 RETURN (ifnull(lvl,0));
END$$

$$

CREATE DEFINER=`zsi`@`%` FUNCTION `getSupplyType`(p_supply_type_id int) RETURNS varchar(100) CHARSET latin1
    DETERMINISTIC
BEGIN
    DECLARE lvl varchar(100);
    SELECT supply_type INTO lvl FROM supply_types WHERE supply_type_id=p_supply_type_id;
 RETURN (lvl);
END$$

CREATE DEFINER=`zsi`@`%` FUNCTION `getSupplyUcost`(p_supply_id int) RETURNS decimal(7,2)
    DETERMINISTIC
BEGIN
    DECLARE lvl decimal(7,2);
    SELECT supply_cost INTO lvl FROM supplies WHERE supply_id=p_supply_id;
 RETURN (lvl);
END$$

CREATE DEFINER=`zsi`@`%` FUNCTION `getSupplyUcostByBrandUnit`(p_supply_brand_id int) RETURNS decimal(7,2)
    DETERMINISTIC
BEGIN
    DECLARE lvl decimal(7,2);
    SELECT supply_cost INTO lvl FROM supply_brands WHERE supply_brand_id=p_supply_brand_id;
 RETURN (lvl);
END$$

CREATE DEFINER=`zsi`@`%` FUNCTION `getSupplyUprice`(p_supply_id int) RETURNS decimal(7,2)
    DETERMINISTIC
BEGIN
    DECLARE lvl decimal(7,2);
    SELECT supply_srp INTO lvl FROM supplies WHERE supply_id=p_supply_id;
 RETURN (lvl);
END$$

CREATE DEFINER=`zsi`@`%` FUNCTION `getToCashBoxAmount`(p_store_daily_cash_id int(5)) RETURNS decimal(7,2)
    DETERMINISTIC
BEGIN
 DECLARE lvl decimal(7,2);
    select ttl_cash_box_amt INTO lvl from store_daily_cash where fr_store_daily_cash_id = p_store_daily_cash_id;
 RETURN (ifnull(lvl,0));
END$$

$$

CREATE DEFINER=`zsi`@`%` FUNCTION `get_store_daily_cash_denom_amt`(p_store_loc_id int,  p_denomination int, p_tran_date DATE) RETURNS int(5)
    DETERMINISTIC
BEGIN
    DECLARE lvl INT(5);
    SELECT cash_amount INTO lvl FROM store_daily_cash_dtls_v WHERE store_loc_id = p_store_loc_id and denomination=p_denomination AND  tran_date = p_tran_date; 
 RETURN (ifnull(lvl,0));
END$$

CREATE DEFINER=`zsi`@`%` FUNCTION `get_store_daily_cash_denom_nextday_qty`(p_store_daily_cash_id int, p_denomination int) RETURNS int(5)
    DETERMINISTIC
BEGIN
    DECLARE lvl INT(5);
    SELECT denomination_qty INTO lvl FROM store_daily_cash_dtls_v WHERE fr_store_daily_cash_id=p_store_daily_cash_id and denomination=p_denomination; 
 RETURN (ifnull(lvl,0));
END$$

CREATE DEFINER=`zsi`@`%` FUNCTION `get_store_daily_cash_denom_qty`(p_store_loc_id int,  p_denomination int, p_tran_date DATE) RETURNS int(5)
    DETERMINISTIC
BEGIN
    DECLARE lvl INT(5);
    SELECT denomination_qty INTO lvl FROM store_daily_cash_dtls_v WHERE store_loc_id = p_store_loc_id and denomination=p_denomination AND  tran_date = p_tran_date; 
 RETURN (ifnull(lvl,0));
END$$

CREATE DEFINER=`zsi`@`%` FUNCTION `get_store_pc_qty`(p_store_loc_id int,  p_loc_supply_brand_id int, p_tran_date DATE) RETURNS decimal(7,2)
    DETERMINISTIC
BEGIN
    DECLARE lvl decimal(7,2);
    SELECT pc_qty INTO lvl FROM loc_pc_dtls_v WHERE store_loc_id = p_store_loc_id and loc_supply_brand_id=p_loc_supply_brand_id AND  DATE_FORMAT(pc_date,'%m/%d/%Y') = p_tran_date; 
 RETURN (ifnull(lvl,0));
END$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Stand-in structure for view `conv_units_v`
--
CREATE TABLE IF NOT EXISTS `conv_units_v` (
`conv_id` int(5) unsigned
,`from_unit_id` varchar(64)
,`conv_unit_id` varchar(64)
,`conv_unit_qty` decimal(5,2)
,`created_by` int(5)
,`created_date` datetime
,`updated_by` int(5)
,`updated_date` datetime
,`cu_desc` varchar(33)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `is_dtls_v`
--
CREATE TABLE IF NOT EXISTS `is_dtls_v` (
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `locations_v`
--
CREATE TABLE IF NOT EXISTS `locations_v` (
`user_loc_id` char(0)
,`loc_id` int(5) unsigned
,`user_id` char(0)
,`location` varchar(100)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `loc_pc_dtls_by_store_loc_v`
--
CREATE TABLE IF NOT EXISTS `loc_pc_dtls_by_store_loc_v` (
`loc_pc_dtl_id` int(5) unsigned
,`loc_pc_id` int(5)
,`loc_supply_brand_id` int(5)
,`store_loc_supply_id` int(5)
,`pc_qty` decimal(7,2)
,`created_by` int(5)
,`created_date` datetime
,`updated_by` int(5)
,`updated_date` datetime
,`loc_id` int(5)
,`store_loc_id` int(5)
,`pc_date` datetime
,`supply_code` varchar(25)
,`unit_desc` varchar(100)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `loc_pc_dtls_group_v`
--
CREATE TABLE IF NOT EXISTS `loc_pc_dtls_group_v` (
`loc_pc_id` int(5)
,`loc_supply_id` int(5)
,`sum_stock_qty` decimal(34,4)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `loc_pc_dtls_v`
--
CREATE TABLE IF NOT EXISTS `loc_pc_dtls_v` (
`loc_pc_dtl_id` int(5) unsigned
,`loc_pc_id` int(5)
,`loc_supply_brand_id` int(5)
,`pc_qty` decimal(7,2)
,`stock_qty` decimal(7,2)
,`loc_id` int(5)
,`store_loc_id` int(5)
,`pc_date` datetime
,`seq_no` int(5)
,`supply_code` varchar(25)
,`brand_name` varchar(64)
,`cu_desc` varchar(33)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `loc_supplies2_v`
--
CREATE TABLE IF NOT EXISTS `loc_supplies2_v` (
`loc_supply_id` int(5) unsigned
,`loc_id` int(5)
,`supply_id` int(5)
,`reorder_level` int(5)
,`max_level` int(5)
,`created_by` int(5)
,`created_date` datetime
,`updated_by` int(5)
,`updated_date` datetime
,`ordered_qty` int(5)
,`seq_no` int(5)
,`supply_code` varchar(25)
,`unit_desc` varchar(100)
,`ttl_stocks` decimal(7,2)
,`store_id` int(5)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `loc_supplies_po_v`
--
CREATE TABLE IF NOT EXISTS `loc_supplies_po_v` (
`loc_id` int(5)
,`loc_supply_id` int(5) unsigned
,`supply_id` int(5)
,`seq_no` int(5)
,`supply_code` varchar(25)
,`reorder_level` int(5)
,`max_level` int(5)
,`unit_desc` varchar(100)
,`ttl_stocks` decimal(7,2)
,`ordered_qty` int(5)
,`store_id` int(5)
,`supplier_id` int(5)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `loc_supplies_v`
--
CREATE TABLE IF NOT EXISTS `loc_supplies_v` (
`loc_id` int(5)
,`loc_supply_id` int(5) unsigned
,`supply_id` int(5)
,`seq_no` int(5)
,`supply_code` varchar(25)
,`reorder_level` int(5)
,`max_level` int(5)
,`unit_desc` varchar(100)
,`ttl_stocks` decimal(7,2)
,`ordered_qty` int(5)
,`store_id` int(5)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `loc_supply_brands_v`
--
CREATE TABLE IF NOT EXISTS `loc_supply_brands_v` (
`loc_supply_brand_id` int(5) unsigned
,`loc_supply_id` int(5)
,`supply_brand_id` int(5)
,`stock_qty` decimal(10,2)
,`created_by` int(5)
,`created_date` datetime
,`updated_by` int(5)
,`updated_date` datetime
,`supply_id` int(5)
,`seq_no` int(5)
,`supply_code` varchar(25)
,`loc_id` int(5)
,`brand_name` varchar(64)
,`cu_desc` varchar(33)
,`brand_supply` varchar(139)
,`conv_unit_qty` decimal(5,2)
,`store_loc_supply_id` char(0)
,`store_id` int(5)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `menu_v`
--
CREATE TABLE IF NOT EXISTS `menu_v` (
`menu_id` int(5) unsigned
,`menu_name` varchar(64)
,`menu_url` varchar(100)
,`menu_type_id` int(5)
,`system_id` int(5)
,`seq_no` int(5)
,`created_by` int(5)
,`created_date` datetime
,`updated_by` int(5)
,`updated_date` datetime
,`menu_type` varchar(100)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `powithbal_v`
--
CREATE TABLE IF NOT EXISTS `powithbal_v` (
`po_id` int(5) unsigned
,`po_no` int(5)
,`po_date` datetime
,`loc_id` int(5)
,`supplier_id` int(5)
,`posted` int(5)
,`created_by` int(5)
,`created_date` datetime
,`updated_by` int(5)
,`updated_date` datetime
,`supplier` varchar(100)
,`location` varchar(100)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `po_dtlswithbal_v`
--
CREATE TABLE IF NOT EXISTS `po_dtlswithbal_v` (
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `po_dtls_v`
--
CREATE TABLE IF NOT EXISTS `po_dtls_v` (
`po_dtl_id` int(5) unsigned
,`po_id` int(5)
,`loc_supply_id` int(5)
,`po_qty` decimal(10,2)
,`bal_qty` decimal(10,2)
,`unit_id` int(5)
,`created_by` int(5)
,`created_date` datetime
,`updated_by` int(5)
,`updated_date` datetime
,`supply_code` varchar(25)
,`unit_desc` varchar(100)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `po_receiving_unposted_v`
--
CREATE TABLE IF NOT EXISTS `po_receiving_unposted_v` (
`po_id` int(5) unsigned
,`po_no` int(5)
,`po_date` datetime
,`loc_id` int(5)
,`supplier_id` int(5)
,`posted` int(5)
,`created_by` int(5)
,`created_date` datetime
,`updated_by` int(5)
,`updated_date` datetime
,`supplier` varchar(100)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `po_unposted_v`
--
CREATE TABLE IF NOT EXISTS `po_unposted_v` (
`po_id` int(5) unsigned
,`po_no` int(5)
,`po_date` datetime
,`loc_id` int(5)
,`supplier_id` int(5)
,`posted` int(5)
,`created_by` int(5)
,`created_date` datetime
,`updated_by` int(5)
,`updated_date` datetime
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `receiving_dtls_po_v`
--
CREATE TABLE IF NOT EXISTS `receiving_dtls_po_v` (
`receiving_dtl_id` int(5) unsigned
,`receiving_id` int(5)
,`po_dtl_id` int(5)
,`supply_brand_id` int(5)
,`dr_qty` decimal(10,2)
,`bal_qty` decimal(10,2)
,`created_by` int(5)
,`created_date` datetime
,`updated_by` int(5)
,`updated_date` datetime
,`supply_code` varchar(25)
,`unit_desc` varchar(100)
,`loc_id` int(5)
,`brand_name` varchar(64)
,`cu_desc` varchar(33)
,`end_qty` decimal(11,2)
,`loc_supply_id` int(5)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `receiving_dtls_v`
--
CREATE TABLE IF NOT EXISTS `receiving_dtls_v` (
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `receiving_unposted_v`
--
CREATE TABLE IF NOT EXISTS `receiving_unposted_v` (
`receiving_id` int(5) unsigned
,`dr_no` int(5)
,`dr_date` datetime
,`po_id` int(5)
,`posted` int(5)
,`created_by` int(5)
,`created_date` datetime
,`updated_by` int(5)
,`updated_date` datetime
,`supplier` varchar(100)
,`location` varchar(100)
,`po_no` int(5)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `revisions_latest_v`
--
CREATE TABLE IF NOT EXISTS `revisions_latest_v` (
`revision_id` int(11)
,`path` varchar(100)
,`filename` varchar(50)
,`filetype` varchar(50)
,`content` text
,`created_by` int(11)
,`created_date` datetime
,`updated_by` int(11)
,`updated_date` datetime
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `sales_staffs_v`
--
CREATE TABLE IF NOT EXISTS `sales_staffs_v` (
`empl_id` int(5) unsigned
,`empl_name` varchar(64)
,`store_loc_id` int(5)
,`position_id` int(5)
,`active` int(5)
,`created_by` int(5)
,`created_date` datetime
,`updated_by` int(5)
,`updated_date` datetime
,`daily_rate` decimal(7,2)
,`loc_id` int(5)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `status_v`
--
CREATE TABLE IF NOT EXISTS `status_v` (
`status_code` varchar(1)
,`status` varchar(9)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `stock_transfer_dtls_v`
--
CREATE TABLE IF NOT EXISTS `stock_transfer_dtls_v` (
`st_dtl_id` int(5) unsigned
,`st_id` int(5)
,`st_qty` decimal(7,2)
,`loc_supply_brand_id` int(5)
,`created_by` int(5)
,`created_date` datetime
,`updated_by` int(5)
,`updated_date` datetime
,`stock_qty` decimal(10,2)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `stock_transfer_unposted_v`
--
CREATE TABLE IF NOT EXISTS `stock_transfer_unposted_v` (
`st_id` int(5) unsigned
,`st_no` int(5)
,`st_date` datetime
,`loc_id` int(5)
,`loc_id_to` int(5)
,`posted` int(5)
,`created_by` int(5)
,`created_date` datetime
,`updated_by` int(5)
,`updated_date` datetime
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `store_bank_depo_dtls_v`
--
CREATE TABLE IF NOT EXISTS `store_bank_depo_dtls_v` (
`store_bank_depo_dtl_id` int(5) unsigned
,`store_bank_depo_id` int(5)
,`bank_ref_id` int(5)
,`depo_pct_share` int(5)
,`depo_amount` decimal(7,2)
,`created_by` int(5)
,`created_date` datetime
,`updated_by` int(5)
,`updated_date` datetime
,`store_loc_id` int(5)
,`act_depo_date` datetime
,`getBankName(a.bank_ref_id)` varchar(100)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `store_daily_cash_dtls_v`
--
CREATE TABLE IF NOT EXISTS `store_daily_cash_dtls_v` (
`store_daily_cash_dtl_id` int(5) unsigned
,`store_daily_cash_id` int(5)
,`denomination` decimal(7,2)
,`denomination_qty` int(5)
,`cash_amount` decimal(7,2)
,`return_denomination_qty` int(5)
,`return_amount` decimal(7,2)
,`created_by` int(5)
,`created_date` datetime
,`updated_by` int(5)
,`updated_date` datetime
,`store_loc_id` int(5)
,`tran_date` datetime
,`fr_store_daily_cash_id` int(5)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `store_loc_exp_dtls_v`
--
CREATE TABLE IF NOT EXISTS `store_loc_exp_dtls_v` (
`store_loc_exp_dtl_id` int(5) unsigned
,`store_loc_exp_id` int(5)
,`exp_desc` varchar(100)
,`exp_amt` decimal(7,2)
,`created_by` int(5)
,`created_date` datetime
,`updated_by` int(5)
,`updated_date` datetime
,`or_no` varchar(20)
,`fr_sales` int(1)
,`store_loc_id` int(5)
,`exp_date` datetime
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `store_loc_sales_exp_dtls_v`
--
CREATE TABLE IF NOT EXISTS `store_loc_sales_exp_dtls_v` (
`store_loc_exp_dtl_id` int(5) unsigned
,`store_loc_exp_id` int(5)
,`exp_desc` varchar(100)
,`exp_amt` decimal(7,2)
,`created_by` int(5)
,`created_date` datetime
,`updated_by` int(5)
,`updated_date` datetime
,`or_no` varchar(20)
,`fr_sales` int(1)
,`store_loc_id` int(5)
,`exp_date` datetime
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `store_loc_supplies2_v`
--
CREATE TABLE IF NOT EXISTS `store_loc_supplies2_v` (
`store_loc_supply_id` char(0)
,`store_loc_id` char(0)
,`store_id` int(5)
,`supply_id` int(5)
,`loc_supply_id` char(0)
,`supply_code` varchar(25)
,`unit_desc` varchar(100)
,`stock_daily_qty` char(0)
,`prev_qty` char(0)
,`unit_price` decimal(7,2)
,`unit_cost` decimal(7,2)
,`loc_supply_brand_id` char(0)
,`loc_id` char(0)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `store_loc_supplies_ref2_v`
--
CREATE TABLE IF NOT EXISTS `store_loc_supplies_ref2_v` (
`store_loc_supply_id` char(0)
,`store_loc_id` char(0)
,`store_id` int(5)
,`supply_id` int(5) unsigned
,`supply_code` varchar(25)
,`unit_desc` varchar(100)
,`stock_daily_qty` char(0)
,`ttl_stocks` char(0)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `store_loc_supplies_ref_v`
--
CREATE TABLE IF NOT EXISTS `store_loc_supplies_ref_v` (
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `store_loc_supplies_v`
--
CREATE TABLE IF NOT EXISTS `store_loc_supplies_v` (
`store_loc_supply_id` int(5) unsigned
,`store_loc_id` int(5)
,`store_id` int(5)
,`supply_id` int(5)
,`loc_supply_id` int(5)
,`supply_code` varchar(25)
,`unit_desc` varchar(100)
,`stock_daily_qty` decimal(5,2)
,`prev_qty` decimal(7,2)
,`unit_price` decimal(7,2)
,`unit_cost` decimal(7,2)
,`loc_supply_brand_id` char(0)
,`loc_id` int(5)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `store_loc_supply_daily_v`
--
CREATE TABLE IF NOT EXISTS `store_loc_supply_daily_v` (
`store_loc_supply_daily_id` int(5) unsigned
,`store_loc_supply_id` int(5)
,`stock_date` date
,`beg_qty` decimal(7,2)
,`remaining_qty` decimal(7,2)
,`is_qty` decimal(7,2)
,`out_qty` decimal(7,2)
,`end_qty` decimal(7,2)
,`unit_price` decimal(7,2)
,`unit_cost` decimal(7,2)
,`created_by` int(5)
,`created_date` datetime
,`updated_by` int(5)
,`updated_date` datetime
,`returned_qty` decimal(7,2)
,`posted` int(5)
,`onhand_qty` decimal(7,2)
,`loc_qty` decimal(7,2)
,`loc_id` int(5)
,`store_loc_id` int(5)
,`supply_code` varchar(25)
,`unit_desc` varchar(100)
,`loc_supply_id` int(5)
,`sales_amount` decimal(14,4)
,`cost_amount` decimal(14,4)
,`supply` varchar(137)
,`supply_id` int(5)
,`getLocSupplyBrandIdByLocSupplyId(loc_supply_id)` int(5)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `store_supplies2_v`
--
CREATE TABLE IF NOT EXISTS `store_supplies2_v` (
`store_id` char(0)
,`store_supply_id` char(0)
,`supply_id` int(5) unsigned
,`supply_code` varchar(25)
,`seq_no` int(5)
,`unit_desc` varchar(100)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `store_supplies_v`
--
CREATE TABLE IF NOT EXISTS `store_supplies_v` (
`store_id` int(5)
,`store_supply_id` int(5) unsigned
,`supply_id` int(5)
,`supply_code` varchar(25)
,`seq_no` int(5)
,`unit_desc` varchar(100)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `store_supply_brands_v`
--
CREATE TABLE IF NOT EXISTS `store_supply_brands_v` (
`store_id` int(5)
,`store_supply_id` int(5) unsigned
,`supply_id` int(5)
,`supply` varchar(90)
,`supply_cost` decimal(7,2)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `supplies2_v`
--
CREATE TABLE IF NOT EXISTS `supplies2_v` (
`loc_id` char(0)
,`loc_supply_id` char(0)
,`supply_id` int(5) unsigned
,`seq_no` int(5)
,`supply_code` varchar(25)
,`reorder_level` char(0)
,`max_level` char(0)
,`unit_desc` varchar(100)
,`ttl_stocks` char(0)
,`ordered_qty` char(0)
,`store_id` char(0)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `supplies_v`
--
CREATE TABLE IF NOT EXISTS `supplies_v` (
`supply_id` int(5) unsigned
,`supply_code` varchar(25)
,`supply_desc` varchar(64)
,`supply_type_id` int(5)
,`created_by` int(5)
,`created_date` datetime
,`updated_by` int(5)
,`updated_date` datetime
,`unit_id` int(5)
,`supply_srp` decimal(7,2)
,`seq_no` int(5)
,`weight_serve` decimal(7,2)
,`supply_cost` decimal(7,2)
,`unit_desc` varchar(100)
,`supply_type` varchar(100)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `supply_brands2_v`
--
CREATE TABLE IF NOT EXISTS `supply_brands2_v` (
`supply_brand_id` char(0)
,`supply_id` char(0)
,`brand_id` int(5) unsigned
,`brand_name` varchar(64)
,`conv_id` char(0)
,`supply_cost` char(0)
,`supply` char(0)
,`cu_desc` char(0)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `supply_brands_po_dtls_v`
--
CREATE TABLE IF NOT EXISTS `supply_brands_po_dtls_v` (
`po_dtl_id` int(5) unsigned
,`po_id` int(5)
,`loc_supply_id` int(5)
,`po_qty` decimal(10,2)
,`bal_qty` decimal(10,2)
,`unit_id` int(5)
,`created_by` int(5)
,`created_date` datetime
,`updated_by` int(5)
,`updated_date` datetime
,`supply_code` varchar(25)
,`unit_desc` varchar(100)
,`supply_brand_id` int(5)
,`brand_name` varchar(64)
,`cu_desc` varchar(33)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `supply_brands_v`
--
CREATE TABLE IF NOT EXISTS `supply_brands_v` (
`supply_brand_id` int(5) unsigned
,`supply_id` int(5)
,`brand_id` int(5)
,`brand_name` varchar(64)
,`conv_id` int(5)
,`supply_cost` decimal(7,2)
,`supply` varchar(90)
,`cu_desc` varchar(33)
,`conv_unit_qty` decimal(5,2)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `supply_is_dtls_grp_v`
--
CREATE TABLE IF NOT EXISTS `supply_is_dtls_grp_v` (
`store_loc_id` int(5)
,`supply_is_id` int(5)
,`is_date` datetime
,`loc_supply_id` int(5)
,`unit_price` decimal(7,2)
,`unit_cost` decimal(7,2)
,`SumISQty` decimal(29,2)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `supply_is_dtls_unposted_v`
--
CREATE TABLE IF NOT EXISTS `supply_is_dtls_unposted_v` (
`supply_is_dtl_id` int(5) unsigned
,`supply_is_id` int(5)
,`supply_is_qty` decimal(7,2)
,`loc_supply_brand_id` int(5)
,`created_by` int(5)
,`created_date` datetime
,`updated_by` int(5)
,`updated_date` datetime
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `supply_is_dtls_v`
--
CREATE TABLE IF NOT EXISTS `supply_is_dtls_v` (
`supply_is_dtl_id` int(5) unsigned
,`supply_is_id` int(5)
,`supply_is_qty` decimal(7,2)
,`loc_supply_brand_id` int(5)
,`created_by` int(5)
,`created_date` datetime
,`updated_by` int(5)
,`updated_date` datetime
,`store_loc_id` int(5)
,`is_date` datetime
,`supply_code` varchar(25)
,`brand_name` varchar(64)
,`cu_desc` varchar(33)
,`loc_supply_id` int(5)
,`supply_id` int(5)
,`unit_price` decimal(7,2)
,`unit_cost` decimal(7,2)
,`store_loc_supply_id` char(0)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `supply_is_unposted_v`
--
CREATE TABLE IF NOT EXISTS `supply_is_unposted_v` (
`supply_is_id` int(5) unsigned
,`is_no` varchar(10)
,`is_date` datetime
,`store_loc_id` int(5)
,`posted` int(5)
,`created_by` int(5)
,`created_date` datetime
,`updated_by` int(5)
,`updated_date` datetime
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `supply_is_v`
--
CREATE TABLE IF NOT EXISTS `supply_is_v` (
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `supply_v`
--
CREATE TABLE IF NOT EXISTS `supply_v` (
`supply_brand_id` int(5) unsigned
,`supply_id` int(5)
,`brand_id` int(5)
,`brand_name` varchar(64)
,`conv_id` int(5)
,`supply_cost` decimal(7,2)
,`supply` varchar(90)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `user_locations2_v`
--
CREATE TABLE IF NOT EXISTS `user_locations2_v` (
`user_loc_id` char(0)
,`loc_id` int(5) unsigned
,`user_id` char(0)
,`location` varchar(100)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `user_locations_v`
--
CREATE TABLE IF NOT EXISTS `user_locations_v` (
`user_loc_id` int(5) unsigned
,`loc_id` int(5)
,`user_id` int(5)
,`location` varchar(100)
);

-- --------------------------------------------------------

--
-- Structure for view `conv_units_v`
--
DROP TABLE IF EXISTS `conv_units_v`;

CREATE ALGORITHM=UNDEFINED DEFINER=`zsi`@`%` SQL SECURITY DEFINER VIEW `conv_units_v` AS select `a`.`conv_id` AS `conv_id`,`a`.`from_unit_id` AS `from_unit_id`,`a`.`conv_unit_id` AS `conv_unit_id`,`a`.`conv_unit_qty` AS `conv_unit_qty`,`a`.`created_by` AS `created_by`,`a`.`created_date` AS `created_date`,`a`.`updated_by` AS `updated_by`,`a`.`updated_date` AS `updated_date`,if((`a`.`from_unit_id` = `a`.`conv_unit_id`),`b`.`unit_sdesc`,concat(`a`.`conv_unit_qty`,' ',`c`.`unit_sdesc`,' per ',`b`.`unit_sdesc`)) AS `cu_desc` from ((`conv_units` `a` join `units` `b`) join `units` `c`) where ((`a`.`from_unit_id` = `b`.`unit_id`) and (`a`.`conv_unit_id` = `c`.`unit_id`));

-- --------------------------------------------------------

--
-- Structure for view `is_dtls_v`
--
DROP TABLE IF EXISTS `is_dtls_v`;
-- in use(#1356 - View 'zsi_sims.is_dtls_v' references invalid table(s) or column(s) or function(s) or definer/invoker of view lack rights to use them)

-- --------------------------------------------------------

--
-- Structure for view `locations_v`
--
DROP TABLE IF EXISTS `locations_v`;

CREATE ALGORITHM=UNDEFINED DEFINER=`zsi`@`%` SQL SECURITY DEFINER VIEW `locations_v` AS select '' AS `user_loc_id`,`b`.`loc_id` AS `loc_id`,'' AS `user_id`,`b`.`location` AS `location` from `locations` `b`;

-- --------------------------------------------------------

--
-- Structure for view `loc_pc_dtls_by_store_loc_v`
--
DROP TABLE IF EXISTS `loc_pc_dtls_by_store_loc_v`;

CREATE ALGORITHM=UNDEFINED DEFINER=`zsi`@`160.153.90.71` SQL SECURITY DEFINER VIEW `loc_pc_dtls_by_store_loc_v` AS select `a`.`loc_pc_dtl_id` AS `loc_pc_dtl_id`,`a`.`loc_pc_id` AS `loc_pc_id`,`a`.`loc_supply_brand_id` AS `loc_supply_brand_id`,`a`.`store_loc_supply_id` AS `store_loc_supply_id`,`a`.`pc_qty` AS `pc_qty`,`a`.`created_by` AS `created_by`,`a`.`created_date` AS `created_date`,`a`.`updated_by` AS `updated_by`,`a`.`updated_date` AS `updated_date`,`c`.`loc_id` AS `loc_id`,`c`.`store_loc_id` AS `store_loc_id`,`c`.`pc_date` AS `pc_date`,`b`.`supply_code` AS `supply_code`,`b`.`unit_desc` AS `unit_desc` from ((`loc_pc_dtls` `a` join `store_loc_supplies_v` `b`) join `loc_pc` `c`) where ((`a`.`store_loc_supply_id` = `b`.`store_loc_supply_id`) and (`a`.`loc_pc_id` = `c`.`loc_pc_id`));

-- --------------------------------------------------------

--
-- Structure for view `loc_pc_dtls_group_v`
--
DROP TABLE IF EXISTS `loc_pc_dtls_group_v`;

CREATE ALGORITHM=UNDEFINED DEFINER=`zsi`@`160.153.90.71` SQL SECURITY DEFINER VIEW `loc_pc_dtls_group_v` AS select `loc_pc_dtls`.`loc_pc_id` AS `loc_pc_id`,`getLocSupplyIdByBrandId`(`loc_pc_dtls`.`loc_supply_brand_id`) AS `loc_supply_id`,sum((`loc_pc_dtls`.`pc_qty` * `getSupplyConvQty`(`loc_pc_dtls`.`loc_supply_brand_id`))) AS `sum_stock_qty` from `loc_pc_dtls` group by `loc_pc_dtls`.`loc_pc_id`,`getLocSupplyIdByBrandId`(`loc_pc_dtls`.`loc_supply_brand_id`);

-- --------------------------------------------------------

--
-- Structure for view `loc_pc_dtls_v`
--
DROP TABLE IF EXISTS `loc_pc_dtls_v`;

CREATE ALGORITHM=UNDEFINED DEFINER=`zsi`@`160.153.90.71` SQL SECURITY DEFINER VIEW `loc_pc_dtls_v` AS select `a`.`loc_pc_dtl_id` AS `loc_pc_dtl_id`,`a`.`loc_pc_id` AS `loc_pc_id`,`a`.`loc_supply_brand_id` AS `loc_supply_brand_id`,`a`.`pc_qty` AS `pc_qty`,`a`.`pc_qty` AS `stock_qty`,`c`.`loc_id` AS `loc_id`,`c`.`store_loc_id` AS `store_loc_id`,`c`.`pc_date` AS `pc_date`,`b`.`seq_no` AS `seq_no`,`b`.`supply_code` AS `supply_code`,`b`.`brand_name` AS `brand_name`,`b`.`cu_desc` AS `cu_desc` from ((`loc_pc_dtls` `a` join `loc_supply_brands_v` `b`) join `loc_pc` `c`) where ((`a`.`loc_supply_brand_id` = `b`.`loc_supply_brand_id`) and (`a`.`loc_pc_id` = `c`.`loc_pc_id`));

-- --------------------------------------------------------

--
-- Structure for view `loc_supplies2_v`
--
DROP TABLE IF EXISTS `loc_supplies2_v`;

CREATE ALGORITHM=UNDEFINED DEFINER=`zsi`@`160.153.90.71` SQL SECURITY DEFINER VIEW `loc_supplies2_v` AS select `a`.`loc_supply_id` AS `loc_supply_id`,`a`.`loc_id` AS `loc_id`,`a`.`supply_id` AS `supply_id`,`a`.`reorder_level` AS `reorder_level`,`a`.`max_level` AS `max_level`,`a`.`created_by` AS `created_by`,`a`.`created_date` AS `created_date`,`a`.`updated_by` AS `updated_by`,`a`.`updated_date` AS `updated_date`,`a`.`ordered_qty` AS `ordered_qty`,`b`.`seq_no` AS `seq_no`,`b`.`supply_code` AS `supply_code`,`b`.`unit_desc` AS `unit_desc`,`getStockCount`(`a`.`loc_supply_id`) AS `ttl_stocks`,`b`.`store_id` AS `store_id` from (`loc_supplies` `a` join `store_supplies_v` `b`) where (`a`.`supply_id` = `b`.`supply_id`);

-- --------------------------------------------------------

--
-- Structure for view `loc_supplies_po_v`
--
DROP TABLE IF EXISTS `loc_supplies_po_v`;

CREATE ALGORITHM=UNDEFINED DEFINER=`zsi`@`%` SQL SECURITY DEFINER VIEW `loc_supplies_po_v` AS select `a`.`loc_id` AS `loc_id`,`a`.`loc_supply_id` AS `loc_supply_id`,`a`.`supply_id` AS `supply_id`,`b`.`seq_no` AS `seq_no`,`b`.`supply_code` AS `supply_code`,`a`.`reorder_level` AS `reorder_level`,`a`.`max_level` AS `max_level`,`b`.`unit_desc` AS `unit_desc`,`getStockCount`(`a`.`loc_supply_id`) AS `ttl_stocks`,`a`.`ordered_qty` AS `ordered_qty`,`b`.`store_id` AS `store_id`,`getSupplierIdByStore`(`b`.`store_id`) AS `supplier_id` from (`loc_supplies` `a` join `store_supplies_v` `b`) where (`a`.`supply_id` = `b`.`supply_id`) order by `b`.`seq_no`;

-- --------------------------------------------------------

--
-- Structure for view `loc_supplies_v`
--
DROP TABLE IF EXISTS `loc_supplies_v`;

CREATE ALGORITHM=UNDEFINED DEFINER=`zsi`@`160.153.90.71` SQL SECURITY DEFINER VIEW `loc_supplies_v` AS select `a`.`loc_id` AS `loc_id`,`a`.`loc_supply_id` AS `loc_supply_id`,`a`.`supply_id` AS `supply_id`,`b`.`seq_no` AS `seq_no`,`b`.`supply_code` AS `supply_code`,`a`.`reorder_level` AS `reorder_level`,`a`.`max_level` AS `max_level`,`b`.`unit_desc` AS `unit_desc`,`getStockCount`(`a`.`loc_supply_id`) AS `ttl_stocks`,`a`.`ordered_qty` AS `ordered_qty`,`b`.`store_id` AS `store_id` from (`loc_supplies` `a` join `store_supplies_v` `b`) where (`a`.`supply_id` = `b`.`supply_id`);

-- --------------------------------------------------------

--
-- Structure for view `loc_supply_brands_v`
--
DROP TABLE IF EXISTS `loc_supply_brands_v`;

CREATE ALGORITHM=UNDEFINED DEFINER=`zsi`@`160.153.90.71` SQL SECURITY DEFINER VIEW `loc_supply_brands_v` AS select `a`.`loc_supply_brand_id` AS `loc_supply_brand_id`,`a`.`loc_supply_id` AS `loc_supply_id`,`a`.`supply_brand_id` AS `supply_brand_id`,`a`.`stock_qty` AS `stock_qty`,`a`.`created_by` AS `created_by`,`a`.`created_date` AS `created_date`,`a`.`updated_by` AS `updated_by`,`a`.`updated_date` AS `updated_date`,`b`.`supply_id` AS `supply_id`,`b`.`seq_no` AS `seq_no`,`b`.`supply_code` AS `supply_code`,`b`.`loc_id` AS `loc_id`,`c`.`brand_name` AS `brand_name`,`c`.`cu_desc` AS `cu_desc`,concat(`b`.`supply_code`,' ',`c`.`brand_name`,' ',`c`.`cu_desc`,' (',`a`.`stock_qty`,')') AS `brand_supply`,`c`.`conv_unit_qty` AS `conv_unit_qty`,'' AS `store_loc_supply_id`,`b`.`store_id` AS `store_id` from ((`loc_supply_brands` `a` join `loc_supplies_v` `b`) join `supply_brands_v` `c`) where ((`a`.`loc_supply_id` = `b`.`loc_supply_id`) and (`a`.`supply_brand_id` = `c`.`supply_brand_id`)) order by `b`.`seq_no`;

-- --------------------------------------------------------

--
-- Structure for view `menu_v`
--
DROP TABLE IF EXISTS `menu_v`;

CREATE ALGORITHM=UNDEFINED DEFINER=`zsi`@`%` SQL SECURITY DEFINER VIEW `menu_v` AS select `menu`.`menu_id` AS `menu_id`,`menu`.`menu_name` AS `menu_name`,`menu`.`menu_url` AS `menu_url`,`menu`.`menu_type_id` AS `menu_type_id`,`menu`.`system_id` AS `system_id`,`menu`.`seq_no` AS `seq_no`,`menu`.`created_by` AS `created_by`,`menu`.`created_date` AS `created_date`,`menu`.`updated_by` AS `updated_by`,`menu`.`updated_date` AS `updated_date`,`getMenuType`(`menu`.`menu_type_id`) AS `menu_type` from `menu` order by `menu`.`menu_type_id`,`menu`.`seq_no`;

-- --------------------------------------------------------

--
-- Structure for view `powithbal_v`
--
DROP TABLE IF EXISTS `powithbal_v`;

CREATE ALGORITHM=UNDEFINED DEFINER=`zsi`@`%` SQL SECURITY DEFINER VIEW `powithbal_v` AS select `po`.`po_id` AS `po_id`,`po`.`po_no` AS `po_no`,`po`.`po_date` AS `po_date`,`po`.`loc_id` AS `loc_id`,`po`.`supplier_id` AS `supplier_id`,`po`.`posted` AS `posted`,`po`.`created_by` AS `created_by`,`po`.`created_date` AS `created_date`,`po`.`updated_by` AS `updated_by`,`po`.`updated_date` AS `updated_date`,`getSupplier`(`po`.`supplier_id`) AS `supplier`,`getLocation`(`po`.`loc_id`) AS `location` from `po` where ((ifnull(`getPOBalCount`(`po`.`po_id`),0) > 0) and (`po`.`posted` = 1));

-- --------------------------------------------------------

--
-- Structure for view `po_dtlswithbal_v`
--
DROP TABLE IF EXISTS `po_dtlswithbal_v`;
-- in use(#1356 - View 'zsi_sims.po_dtlswithbal_v' references invalid table(s) or column(s) or function(s) or definer/invoker of view lack rights to use them)

-- --------------------------------------------------------

--
-- Structure for view `po_dtls_v`
--
DROP TABLE IF EXISTS `po_dtls_v`;

CREATE ALGORITHM=UNDEFINED DEFINER=`zsi`@`160.153.90.71` SQL SECURITY DEFINER VIEW `po_dtls_v` AS select `a`.`po_dtl_id` AS `po_dtl_id`,`a`.`po_id` AS `po_id`,`a`.`loc_supply_id` AS `loc_supply_id`,`a`.`po_qty` AS `po_qty`,`a`.`bal_qty` AS `bal_qty`,`a`.`unit_id` AS `unit_id`,`a`.`created_by` AS `created_by`,`a`.`created_date` AS `created_date`,`a`.`updated_by` AS `updated_by`,`a`.`updated_date` AS `updated_date`,`b`.`supply_code` AS `supply_code`,`b`.`unit_desc` AS `unit_desc` from (`po_dtls` `a` join `loc_supplies_v` `b`) where (`a`.`loc_supply_id` = `b`.`loc_supply_id`);

-- --------------------------------------------------------

--
-- Structure for view `po_receiving_unposted_v`
--
DROP TABLE IF EXISTS `po_receiving_unposted_v`;

CREATE ALGORITHM=UNDEFINED DEFINER=`zsi`@`%` SQL SECURITY DEFINER VIEW `po_receiving_unposted_v` AS select `a`.`po_id` AS `po_id`,`a`.`po_no` AS `po_no`,`a`.`po_date` AS `po_date`,`a`.`loc_id` AS `loc_id`,`a`.`supplier_id` AS `supplier_id`,`a`.`posted` AS `posted`,`a`.`created_by` AS `created_by`,`a`.`created_date` AS `created_date`,`a`.`updated_by` AS `updated_by`,`a`.`updated_date` AS `updated_date`,`a`.`supplier` AS `supplier` from `powithbal_v` `a` where (not(exists(select `b`.`po_id` from `receiving` `b` where ((`b`.`posted` = 0) and (`b`.`po_id` = `a`.`po_id`)))));

-- --------------------------------------------------------

--
-- Structure for view `po_unposted_v`
--
DROP TABLE IF EXISTS `po_unposted_v`;

CREATE ALGORITHM=UNDEFINED DEFINER=`zsi`@`%` SQL SECURITY DEFINER VIEW `po_unposted_v` AS select `po`.`po_id` AS `po_id`,`po`.`po_no` AS `po_no`,`po`.`po_date` AS `po_date`,`po`.`loc_id` AS `loc_id`,`po`.`supplier_id` AS `supplier_id`,`po`.`posted` AS `posted`,`po`.`created_by` AS `created_by`,`po`.`created_date` AS `created_date`,`po`.`updated_by` AS `updated_by`,`po`.`updated_date` AS `updated_date` from `po` where (`po`.`posted` = 0);

-- --------------------------------------------------------

--
-- Structure for view `receiving_dtls_po_v`
--
DROP TABLE IF EXISTS `receiving_dtls_po_v`;

CREATE ALGORITHM=UNDEFINED DEFINER=`zsi`@`160.153.90.71` SQL SECURITY DEFINER VIEW `receiving_dtls_po_v` AS select `a`.`receiving_dtl_id` AS `receiving_dtl_id`,`a`.`receiving_id` AS `receiving_id`,`a`.`po_dtl_id` AS `po_dtl_id`,`a`.`supply_brand_id` AS `supply_brand_id`,`a`.`dr_qty` AS `dr_qty`,`a`.`bal_qty` AS `bal_qty`,`a`.`created_by` AS `created_by`,`a`.`created_date` AS `created_date`,`a`.`updated_by` AS `updated_by`,`a`.`updated_date` AS `updated_date`,`b`.`supply_code` AS `supply_code`,`b`.`unit_desc` AS `unit_desc`,`getPOLocId`(`b`.`po_id`) AS `loc_id`,`b`.`brand_name` AS `brand_name`,`b`.`cu_desc` AS `cu_desc`,(`a`.`bal_qty` - `a`.`dr_qty`) AS `end_qty`,`b`.`loc_supply_id` AS `loc_supply_id` from (`receiving_dtls` `a` join `supply_brands_po_dtls_v` `b`) where ((`a`.`po_dtl_id` = `b`.`po_dtl_id`) and (`a`.`supply_brand_id` = `b`.`supply_brand_id`));

-- --------------------------------------------------------

--
-- Structure for view `receiving_dtls_v`
--
DROP TABLE IF EXISTS `receiving_dtls_v`;
-- in use(#1356 - View 'zsi_sims.receiving_dtls_v' references invalid table(s) or column(s) or function(s) or definer/invoker of view lack rights to use them)

-- --------------------------------------------------------

--
-- Structure for view `receiving_unposted_v`
--
DROP TABLE IF EXISTS `receiving_unposted_v`;

CREATE ALGORITHM=UNDEFINED DEFINER=`zsi`@`%` SQL SECURITY DEFINER VIEW `receiving_unposted_v` AS select `a`.`receiving_id` AS `receiving_id`,`a`.`dr_no` AS `dr_no`,`a`.`dr_date` AS `dr_date`,`a`.`po_id` AS `po_id`,`a`.`posted` AS `posted`,`a`.`created_by` AS `created_by`,`a`.`created_date` AS `created_date`,`a`.`updated_by` AS `updated_by`,`a`.`updated_date` AS `updated_date`,`b`.`supplier` AS `supplier`,`b`.`location` AS `location`,`b`.`po_no` AS `po_no` from (`receiving` `a` join `powithbal_v` `b`) where ((`a`.`posted` = 0) and (`a`.`po_id` = `b`.`po_id`));

-- --------------------------------------------------------

--
-- Structure for view `revisions_latest_v`
--
DROP TABLE IF EXISTS `revisions_latest_v`;

CREATE ALGORITHM=UNDEFINED DEFINER=`zsi`@`%` SQL SECURITY DEFINER VIEW `revisions_latest_v` AS select `revision_logs`.`revision_id` AS `revision_id`,`revision_logs`.`path` AS `path`,`revision_logs`.`filename` AS `filename`,`revision_logs`.`filetype` AS `filetype`,`revision_logs`.`content` AS `content`,`revision_logs`.`created_by` AS `created_by`,`revision_logs`.`created_date` AS `created_date`,`revision_logs`.`updated_by` AS `updated_by`,`revision_logs`.`updated_date` AS `updated_date` from `revision_logs` where `revision_logs`.`revision_id` in (select distinct `getlatestrevid`(`revision_logs`.`filename`) AS `revision_id` from `revision_logs`);

-- --------------------------------------------------------

--
-- Structure for view `sales_staffs_v`
--
DROP TABLE IF EXISTS `sales_staffs_v`;

CREATE ALGORITHM=UNDEFINED DEFINER=`zsi`@`%` SQL SECURITY DEFINER VIEW `sales_staffs_v` AS select `employees`.`empl_id` AS `empl_id`,`employees`.`empl_name` AS `empl_name`,`employees`.`store_loc_id` AS `store_loc_id`,`employees`.`position_id` AS `position_id`,`employees`.`active` AS `active`,`employees`.`created_by` AS `created_by`,`employees`.`created_date` AS `created_date`,`employees`.`updated_by` AS `updated_by`,`employees`.`updated_date` AS `updated_date`,`employees`.`daily_rate` AS `daily_rate`,`employees`.`loc_id` AS `loc_id` from `employees` where (`employees`.`position_id` = 4);

-- --------------------------------------------------------

--
-- Structure for view `status_v`
--
DROP TABLE IF EXISTS `status_v`;

CREATE ALGORITHM=UNDEFINED DEFINER=`zsi`@`160.153.90.71` SQL SECURITY DEFINER VIEW `status_v` AS select 'O' AS `status_code`,'Open' AS `status` union select 'C' AS `status_code`,'Closed' AS `status` union select 'X' AS `status_code`,'Cancelled' AS `status`;

-- --------------------------------------------------------

--
-- Structure for view `stock_transfer_dtls_v`
--
DROP TABLE IF EXISTS `stock_transfer_dtls_v`;

CREATE ALGORITHM=UNDEFINED DEFINER=`zsi`@`%` SQL SECURITY DEFINER VIEW `stock_transfer_dtls_v` AS select `a`.`st_dtl_id` AS `st_dtl_id`,`a`.`st_id` AS `st_id`,`a`.`st_qty` AS `st_qty`,`a`.`loc_supply_brand_id` AS `loc_supply_brand_id`,`a`.`created_by` AS `created_by`,`a`.`created_date` AS `created_date`,`a`.`updated_by` AS `updated_by`,`a`.`updated_date` AS `updated_date`,`b`.`stock_qty` AS `stock_qty` from (`stock_transfer_dtls` `a` join `loc_supply_brands_v` `b`) where (`a`.`loc_supply_brand_id` = `b`.`loc_supply_brand_id`);

-- --------------------------------------------------------

--
-- Structure for view `stock_transfer_unposted_v`
--
DROP TABLE IF EXISTS `stock_transfer_unposted_v`;

CREATE ALGORITHM=UNDEFINED DEFINER=`zsi`@`%` SQL SECURITY DEFINER VIEW `stock_transfer_unposted_v` AS select `stock_transfer`.`st_id` AS `st_id`,`stock_transfer`.`st_no` AS `st_no`,`stock_transfer`.`st_date` AS `st_date`,`stock_transfer`.`loc_id` AS `loc_id`,`stock_transfer`.`loc_id_to` AS `loc_id_to`,`stock_transfer`.`posted` AS `posted`,`stock_transfer`.`created_by` AS `created_by`,`stock_transfer`.`created_date` AS `created_date`,`stock_transfer`.`updated_by` AS `updated_by`,`stock_transfer`.`updated_date` AS `updated_date` from `stock_transfer` where (`stock_transfer`.`posted` = 0);

-- --------------------------------------------------------

--
-- Structure for view `store_bank_depo_dtls_v`
--
DROP TABLE IF EXISTS `store_bank_depo_dtls_v`;

CREATE ALGORITHM=UNDEFINED DEFINER=`zsi`@`160.153.90.71` SQL SECURITY DEFINER VIEW `store_bank_depo_dtls_v` AS select `a`.`store_bank_depo_dtl_id` AS `store_bank_depo_dtl_id`,`a`.`store_bank_depo_id` AS `store_bank_depo_id`,`a`.`bank_ref_id` AS `bank_ref_id`,`a`.`depo_pct_share` AS `depo_pct_share`,`a`.`depo_amount` AS `depo_amount`,`a`.`created_by` AS `created_by`,`a`.`created_date` AS `created_date`,`a`.`updated_by` AS `updated_by`,`a`.`updated_date` AS `updated_date`,`b`.`store_loc_id` AS `store_loc_id`,`b`.`act_depo_date` AS `act_depo_date`,`getBankName`(`a`.`bank_ref_id`) AS `getBankName(a.bank_ref_id)` from (`store_bank_depo_dtls` `a` join `store_bank_depo` `b`) where (`a`.`store_bank_depo_id` = `b`.`store_bank_depo_id`);

-- --------------------------------------------------------

--
-- Structure for view `store_daily_cash_dtls_v`
--
DROP TABLE IF EXISTS `store_daily_cash_dtls_v`;

CREATE ALGORITHM=UNDEFINED DEFINER=`zsi`@`%` SQL SECURITY DEFINER VIEW `store_daily_cash_dtls_v` AS select `a`.`store_daily_cash_dtl_id` AS `store_daily_cash_dtl_id`,`a`.`store_daily_cash_id` AS `store_daily_cash_id`,`a`.`denomination` AS `denomination`,`a`.`denomination_qty` AS `denomination_qty`,`a`.`cash_amount` AS `cash_amount`,`a`.`return_denomination_qty` AS `return_denomination_qty`,`a`.`return_amount` AS `return_amount`,`a`.`created_by` AS `created_by`,`a`.`created_date` AS `created_date`,`a`.`updated_by` AS `updated_by`,`a`.`updated_date` AS `updated_date`,`b`.`store_loc_id` AS `store_loc_id`,`b`.`tran_date` AS `tran_date`,`b`.`fr_store_daily_cash_id` AS `fr_store_daily_cash_id` from (`store_daily_cash_dtls` `a` join `store_daily_cash` `b`) where (`a`.`store_daily_cash_id` = `b`.`store_daily_cash_id`);

-- --------------------------------------------------------

--
-- Structure for view `store_loc_exp_dtls_v`
--
DROP TABLE IF EXISTS `store_loc_exp_dtls_v`;

CREATE ALGORITHM=UNDEFINED DEFINER=`zsi`@`%` SQL SECURITY DEFINER VIEW `store_loc_exp_dtls_v` AS select `a`.`store_loc_exp_dtl_id` AS `store_loc_exp_dtl_id`,`a`.`store_loc_exp_id` AS `store_loc_exp_id`,`a`.`exp_desc` AS `exp_desc`,`a`.`exp_amt` AS `exp_amt`,`a`.`created_by` AS `created_by`,`a`.`created_date` AS `created_date`,`a`.`updated_by` AS `updated_by`,`a`.`updated_date` AS `updated_date`,`a`.`or_no` AS `or_no`,`a`.`fr_sales` AS `fr_sales`,`b`.`store_loc_id` AS `store_loc_id`,`b`.`exp_date` AS `exp_date` from (`store_loc_exp_dtls` `a` join `store_loc_exp` `b`) where ((`a`.`store_loc_exp_id` = `b`.`store_loc_exp_id`) and (`a`.`fr_sales` = 0));

-- --------------------------------------------------------

--
-- Structure for view `store_loc_sales_exp_dtls_v`
--
DROP TABLE IF EXISTS `store_loc_sales_exp_dtls_v`;

CREATE ALGORITHM=UNDEFINED DEFINER=`zsi`@`%` SQL SECURITY DEFINER VIEW `store_loc_sales_exp_dtls_v` AS select `a`.`store_loc_exp_dtl_id` AS `store_loc_exp_dtl_id`,`a`.`store_loc_exp_id` AS `store_loc_exp_id`,`a`.`exp_desc` AS `exp_desc`,`a`.`exp_amt` AS `exp_amt`,`a`.`created_by` AS `created_by`,`a`.`created_date` AS `created_date`,`a`.`updated_by` AS `updated_by`,`a`.`updated_date` AS `updated_date`,`a`.`or_no` AS `or_no`,`a`.`fr_sales` AS `fr_sales`,`b`.`store_loc_id` AS `store_loc_id`,`b`.`exp_date` AS `exp_date` from (`store_loc_exp_dtls` `a` join `store_loc_exp` `b`) where ((`a`.`store_loc_exp_id` = `b`.`store_loc_exp_id`) and (`a`.`fr_sales` = 1));

-- --------------------------------------------------------

--
-- Structure for view `store_loc_supplies2_v`
--
DROP TABLE IF EXISTS `store_loc_supplies2_v`;

CREATE ALGORITHM=UNDEFINED DEFINER=`zsi`@`160.153.90.71` SQL SECURITY DEFINER VIEW `store_loc_supplies2_v` AS select '' AS `store_loc_supply_id`,'' AS `store_loc_id`,`a`.`store_id` AS `store_id`,`a`.`supply_id` AS `supply_id`,'' AS `loc_supply_id`,`b`.`supply_code` AS `supply_code`,`b`.`unit_desc` AS `unit_desc`,'' AS `stock_daily_qty`,'' AS `prev_qty`,`getSupplyUprice`(`b`.`supply_id`) AS `unit_price`,`getSupplyUcost`(`b`.`supply_id`) AS `unit_cost`,'' AS `loc_supply_brand_id`,'' AS `loc_id` from (`store_supplies` `a` join `supplies_v` `b`) where (`a`.`supply_id` = `b`.`supply_id`);

-- --------------------------------------------------------

--
-- Structure for view `store_loc_supplies_ref2_v`
--
DROP TABLE IF EXISTS `store_loc_supplies_ref2_v`;

CREATE ALGORITHM=UNDEFINED DEFINER=`zsi`@`%` SQL SECURITY DEFINER VIEW `store_loc_supplies_ref2_v` AS select '' AS `store_loc_supply_id`,'' AS `store_loc_id`,`a`.`store_id` AS `store_id`,`b`.`supply_id` AS `supply_id`,`b`.`supply_code` AS `supply_code`,`b`.`unit_desc` AS `unit_desc`,'' AS `stock_daily_qty`,'' AS `ttl_stocks` from (`store_supplies` `a` join `supplies_v` `b`) where (`a`.`supply_id` = `b`.`supply_id`);

-- --------------------------------------------------------

--
-- Structure for view `store_loc_supplies_ref_v`
--
DROP TABLE IF EXISTS `store_loc_supplies_ref_v`;
-- in use(#1356 - View 'zsi_sims.store_loc_supplies_ref_v' references invalid table(s) or column(s) or function(s) or definer/invoker of view lack rights to use them)

-- --------------------------------------------------------

--
-- Structure for view `store_loc_supplies_v`
--
DROP TABLE IF EXISTS `store_loc_supplies_v`;

CREATE ALGORITHM=UNDEFINED DEFINER=`zsi`@`%` SQL SECURITY DEFINER VIEW `store_loc_supplies_v` AS select `a`.`store_loc_supply_id` AS `store_loc_supply_id`,`a`.`store_loc_id` AS `store_loc_id`,`b`.`store_id` AS `store_id`,`b`.`supply_id` AS `supply_id`,`a`.`loc_supply_id` AS `loc_supply_id`,`b`.`supply_code` AS `supply_code`,`b`.`unit_desc` AS `unit_desc`,`a`.`stock_daily_qty` AS `stock_daily_qty`,ifnull(`a`.`prev_qty`,0) AS `prev_qty`,`getSupplyUprice`(`b`.`supply_id`) AS `unit_price`,`getSupplyUcost`(`b`.`supply_id`) AS `unit_cost`,'' AS `loc_supply_brand_id`,`b`.`loc_id` AS `loc_id` from (`store_loc_supplies` `a` join `loc_supplies_v` `b`) where (`a`.`loc_supply_id` = `b`.`loc_supply_id`) order by `b`.`seq_no`;

-- --------------------------------------------------------

--
-- Structure for view `store_loc_supply_daily_v`
--
DROP TABLE IF EXISTS `store_loc_supply_daily_v`;

CREATE ALGORITHM=UNDEFINED DEFINER=`zsi`@`160.153.90.71` SQL SECURITY DEFINER VIEW `store_loc_supply_daily_v` AS select `a`.`store_loc_supply_daily_id` AS `store_loc_supply_daily_id`,`a`.`store_loc_supply_id` AS `store_loc_supply_id`,`a`.`stock_date` AS `stock_date`,`a`.`beg_qty` AS `beg_qty`,`a`.`remaining_qty` AS `remaining_qty`,`a`.`is_qty` AS `is_qty`,`a`.`out_qty` AS `out_qty`,`a`.`end_qty` AS `end_qty`,`a`.`unit_price` AS `unit_price`,`a`.`unit_cost` AS `unit_cost`,`a`.`created_by` AS `created_by`,`a`.`created_date` AS `created_date`,`a`.`updated_by` AS `updated_by`,`a`.`updated_date` AS `updated_date`,`a`.`returned_qty` AS `returned_qty`,`a`.`posted` AS `posted`,`a`.`onhand_qty` AS `onhand_qty`,`a`.`loc_qty` AS `loc_qty`,`b`.`loc_id` AS `loc_id`,`b`.`store_loc_id` AS `store_loc_id`,`b`.`supply_code` AS `supply_code`,`b`.`unit_desc` AS `unit_desc`,`b`.`loc_supply_id` AS `loc_supply_id`,(ifnull(`a`.`unit_price`,0) * ifnull(`a`.`out_qty`,0)) AS `sales_amount`,(ifnull(`a`.`unit_cost`,0) * ifnull(`a`.`out_qty`,0)) AS `cost_amount`,concat(`b`.`supply_code`,' (',`a`.`remaining_qty`,convert(`b`.`unit_desc` using utf8),')') AS `supply`,`b`.`supply_id` AS `supply_id`,`getLocSupplyBrandIdByLocSupplyId`(`b`.`loc_supply_id`) AS `getLocSupplyBrandIdByLocSupplyId(loc_supply_id)` from (`store_loc_supply_daily` `a` join `store_loc_supplies_v` `b`) where (`a`.`store_loc_supply_id` = `b`.`store_loc_supply_id`);

-- --------------------------------------------------------

--
-- Structure for view `store_supplies2_v`
--
DROP TABLE IF EXISTS `store_supplies2_v`;

CREATE ALGORITHM=UNDEFINED DEFINER=`zsi`@`160.153.90.71` SQL SECURITY DEFINER VIEW `store_supplies2_v` AS select '' AS `store_id`,'' AS `store_supply_id`,`supplies_v`.`supply_id` AS `supply_id`,`supplies_v`.`supply_code` AS `supply_code`,`supplies_v`.`seq_no` AS `seq_no`,`supplies_v`.`unit_desc` AS `unit_desc` from `supplies_v`;

-- --------------------------------------------------------

--
-- Structure for view `store_supplies_v`
--
DROP TABLE IF EXISTS `store_supplies_v`;

CREATE ALGORITHM=UNDEFINED DEFINER=`zsi`@`160.153.90.71` SQL SECURITY DEFINER VIEW `store_supplies_v` AS select `a`.`store_id` AS `store_id`,`a`.`store_supply_id` AS `store_supply_id`,`a`.`supply_id` AS `supply_id`,`b`.`supply_code` AS `supply_code`,`b`.`seq_no` AS `seq_no`,`b`.`unit_desc` AS `unit_desc` from (`store_supplies` `a` join `supplies_v` `b`) where (`a`.`supply_id` = `b`.`supply_id`);

-- --------------------------------------------------------

--
-- Structure for view `store_supply_brands_v`
--
DROP TABLE IF EXISTS `store_supply_brands_v`;

CREATE ALGORITHM=UNDEFINED DEFINER=`zsi`@`%` SQL SECURITY DEFINER VIEW `store_supply_brands_v` AS select `a`.`store_id` AS `store_id`,`a`.`store_supply_id` AS `store_supply_id`,`a`.`supply_id` AS `supply_id`,`b`.`supply` AS `supply`,`b`.`supply_cost` AS `supply_cost` from (`store_supplies` `a` join `supply_brands_v` `b`) where (`a`.`supply_id` = `b`.`supply_id`);

-- --------------------------------------------------------

--
-- Structure for view `supplies2_v`
--
DROP TABLE IF EXISTS `supplies2_v`;

CREATE ALGORITHM=UNDEFINED DEFINER=`zsi`@`160.153.90.71` SQL SECURITY DEFINER VIEW `supplies2_v` AS select '' AS `loc_id`,'' AS `loc_supply_id`,`b`.`supply_id` AS `supply_id`,`b`.`seq_no` AS `seq_no`,`b`.`supply_code` AS `supply_code`,'' AS `reorder_level`,'' AS `max_level`,`b`.`unit_desc` AS `unit_desc`,'' AS `ttl_stocks`,'' AS `ordered_qty`,'' AS `store_id` from (`store_supplies` `a` join `supplies_v` `b`) where (`a`.`supply_id` = `b`.`supply_id`);

-- --------------------------------------------------------

--
-- Structure for view `supplies_v`
--
DROP TABLE IF EXISTS `supplies_v`;

CREATE ALGORITHM=UNDEFINED DEFINER=`zsi`@`%` SQL SECURITY DEFINER VIEW `supplies_v` AS select `supplies`.`supply_id` AS `supply_id`,`supplies`.`supply_code` AS `supply_code`,`supplies`.`supply_desc` AS `supply_desc`,`supplies`.`supply_type_id` AS `supply_type_id`,`supplies`.`created_by` AS `created_by`,`supplies`.`created_date` AS `created_date`,`supplies`.`updated_by` AS `updated_by`,`supplies`.`updated_date` AS `updated_date`,`supplies`.`unit_id` AS `unit_id`,`supplies`.`supply_srp` AS `supply_srp`,`supplies`.`seq_no` AS `seq_no`,`supplies`.`weight_serve` AS `weight_serve`,`supplies`.`supply_cost` AS `supply_cost`,`getUnitSDesc`(`supplies`.`unit_id`) AS `unit_desc`,`getSupplyType`(`supplies`.`supply_type_id`) AS `supply_type` from `supplies`;

-- --------------------------------------------------------

--
-- Structure for view `supply_brands2_v`
--
DROP TABLE IF EXISTS `supply_brands2_v`;

CREATE ALGORITHM=UNDEFINED DEFINER=`zsi`@`%` SQL SECURITY DEFINER VIEW `supply_brands2_v` AS select '' AS `supply_brand_id`,'' AS `supply_id`,`brands`.`brand_id` AS `brand_id`,`brands`.`brand_name` AS `brand_name`,'' AS `conv_id`,'' AS `supply_cost`,'' AS `supply`,'' AS `cu_desc` from `brands`;

-- --------------------------------------------------------

--
-- Structure for view `supply_brands_po_dtls_v`
--
DROP TABLE IF EXISTS `supply_brands_po_dtls_v`;

CREATE ALGORITHM=UNDEFINED DEFINER=`zsi`@`160.153.90.71` SQL SECURITY DEFINER VIEW `supply_brands_po_dtls_v` AS select `a`.`po_dtl_id` AS `po_dtl_id`,`a`.`po_id` AS `po_id`,`a`.`loc_supply_id` AS `loc_supply_id`,`a`.`po_qty` AS `po_qty`,`a`.`bal_qty` AS `bal_qty`,`a`.`unit_id` AS `unit_id`,`a`.`created_by` AS `created_by`,`a`.`created_date` AS `created_date`,`a`.`updated_by` AS `updated_by`,`a`.`updated_date` AS `updated_date`,`a`.`supply_code` AS `supply_code`,`a`.`unit_desc` AS `unit_desc`,`b`.`supply_brand_id` AS `supply_brand_id`,`b`.`brand_name` AS `brand_name`,`b`.`cu_desc` AS `cu_desc` from (`po_dtls_v` `a` join `loc_supply_brands_v` `b`) where (`a`.`loc_supply_id` = `b`.`loc_supply_id`);

-- --------------------------------------------------------

--
-- Structure for view `supply_brands_v`
--
DROP TABLE IF EXISTS `supply_brands_v`;

CREATE ALGORITHM=UNDEFINED DEFINER=`zsi`@`%` SQL SECURITY DEFINER VIEW `supply_brands_v` AS select `a`.`supply_brand_id` AS `supply_brand_id`,`a`.`supply_id` AS `supply_id`,`a`.`brand_id` AS `brand_id`,`b`.`brand_name` AS `brand_name`,`a`.`conv_id` AS `conv_id`,`a`.`supply_cost` AS `supply_cost`,if((`a`.`brand_id` = 1),`c`.`supply_code`,concat(`c`.`supply_code`,' ',`b`.`brand_name`)) AS `supply`,`d`.`cu_desc` AS `cu_desc`,`d`.`conv_unit_qty` AS `conv_unit_qty` from (((`supply_brands` `a` join `brands` `b`) join `supplies` `c`) join `conv_units_v` `d`) where ((`a`.`brand_id` = `b`.`brand_id`) and (`a`.`supply_id` = `c`.`supply_id`) and (`a`.`conv_id` = `d`.`conv_id`));

-- --------------------------------------------------------

--
-- Structure for view `supply_is_dtls_grp_v`
--
DROP TABLE IF EXISTS `supply_is_dtls_grp_v`;

CREATE ALGORITHM=UNDEFINED DEFINER=`zsi`@`%` SQL SECURITY DEFINER VIEW `supply_is_dtls_grp_v` AS select `supply_is_dtls_v`.`store_loc_id` AS `store_loc_id`,`supply_is_dtls_v`.`supply_is_id` AS `supply_is_id`,`supply_is_dtls_v`.`is_date` AS `is_date`,`supply_is_dtls_v`.`loc_supply_id` AS `loc_supply_id`,`supply_is_dtls_v`.`unit_price` AS `unit_price`,`supply_is_dtls_v`.`unit_cost` AS `unit_cost`,sum(`supply_is_dtls_v`.`supply_is_qty`) AS `SumISQty` from `supply_is_dtls_v` group by `supply_is_dtls_v`.`store_loc_id`,`supply_is_dtls_v`.`supply_is_id`,`supply_is_dtls_v`.`is_date`,`supply_is_dtls_v`.`loc_supply_id`,`supply_is_dtls_v`.`unit_price`,`supply_is_dtls_v`.`unit_cost`;

-- --------------------------------------------------------

--
-- Structure for view `supply_is_dtls_unposted_v`
--
DROP TABLE IF EXISTS `supply_is_dtls_unposted_v`;

CREATE ALGORITHM=UNDEFINED DEFINER=`zsi`@`%` SQL SECURITY DEFINER VIEW `supply_is_dtls_unposted_v` AS select `a`.`supply_is_dtl_id` AS `supply_is_dtl_id`,`a`.`supply_is_id` AS `supply_is_id`,`a`.`supply_is_qty` AS `supply_is_qty`,`a`.`loc_supply_brand_id` AS `loc_supply_brand_id`,`a`.`created_by` AS `created_by`,`a`.`created_date` AS `created_date`,`a`.`updated_by` AS `updated_by`,`a`.`updated_date` AS `updated_date` from ((`supply_is_dtls` `a` join `store_loc_supplies_v` `b`) join `supply_is` `c`) where ((`a`.`supply_is_id` = `c`.`supply_is_id`) and (`c`.`store_loc_id` = `b`.`store_loc_id`) and (`c`.`posted` = 0));

-- --------------------------------------------------------

--
-- Structure for view `supply_is_dtls_v`
--
DROP TABLE IF EXISTS `supply_is_dtls_v`;

CREATE ALGORITHM=UNDEFINED DEFINER=`zsi`@`160.153.90.71` SQL SECURITY DEFINER VIEW `supply_is_dtls_v` AS select `a`.`supply_is_dtl_id` AS `supply_is_dtl_id`,`a`.`supply_is_id` AS `supply_is_id`,`a`.`supply_is_qty` AS `supply_is_qty`,`a`.`loc_supply_brand_id` AS `loc_supply_brand_id`,`a`.`created_by` AS `created_by`,`a`.`created_date` AS `created_date`,`a`.`updated_by` AS `updated_by`,`a`.`updated_date` AS `updated_date`,`b`.`store_loc_id` AS `store_loc_id`,`b`.`is_date` AS `is_date`,`c`.`supply_code` AS `supply_code`,`c`.`brand_name` AS `brand_name`,`c`.`cu_desc` AS `cu_desc`,`c`.`loc_supply_id` AS `loc_supply_id`,`c`.`supply_id` AS `supply_id`,`getSupplyUprice`(`c`.`supply_id`) AS `unit_price`,`getSupplyUcost`(`c`.`supply_id`) AS `unit_cost`,`c`.`store_loc_supply_id` AS `store_loc_supply_id` from ((`supply_is_dtls` `a` join `supply_is` `b`) join `loc_supply_brands_v` `c`) where ((`a`.`supply_is_id` = `b`.`supply_is_id`) and (`a`.`loc_supply_brand_id` = `c`.`loc_supply_brand_id`));

-- --------------------------------------------------------

--
-- Structure for view `supply_is_unposted_v`
--
DROP TABLE IF EXISTS `supply_is_unposted_v`;

CREATE ALGORITHM=UNDEFINED DEFINER=`zsi`@`%` SQL SECURITY DEFINER VIEW `supply_is_unposted_v` AS select `supply_is`.`supply_is_id` AS `supply_is_id`,`supply_is`.`is_no` AS `is_no`,`supply_is`.`is_date` AS `is_date`,`supply_is`.`store_loc_id` AS `store_loc_id`,`supply_is`.`posted` AS `posted`,`supply_is`.`created_by` AS `created_by`,`supply_is`.`created_date` AS `created_date`,`supply_is`.`updated_by` AS `updated_by`,`supply_is`.`updated_date` AS `updated_date` from `supply_is` where (`supply_is`.`posted` = 0);

-- --------------------------------------------------------

--
-- Structure for view `supply_is_v`
--
DROP TABLE IF EXISTS `supply_is_v`;
-- in use(#1356 - View 'zsi_sims.supply_is_v' references invalid table(s) or column(s) or function(s) or definer/invoker of view lack rights to use them)

-- --------------------------------------------------------

--
-- Structure for view `supply_v`
--
DROP TABLE IF EXISTS `supply_v`;

CREATE ALGORITHM=UNDEFINED DEFINER=`zsi`@`%` SQL SECURITY DEFINER VIEW `supply_v` AS select `a`.`supply_brand_id` AS `supply_brand_id`,`a`.`supply_id` AS `supply_id`,`a`.`brand_id` AS `brand_id`,`b`.`brand_name` AS `brand_name`,`a`.`conv_id` AS `conv_id`,`a`.`supply_cost` AS `supply_cost`,if((`a`.`brand_id` = 1),`c`.`supply_code`,concat(`c`.`supply_code`,' ',`b`.`brand_name`)) AS `supply` from ((`supply_brands` `a` join `brands` `b`) join `supplies` `c`) where ((`a`.`brand_id` = `b`.`brand_id`) and (`a`.`supply_id` = `c`.`supply_id`));

-- --------------------------------------------------------

--
-- Structure for view `user_locations2_v`
--
DROP TABLE IF EXISTS `user_locations2_v`;

CREATE ALGORITHM=UNDEFINED DEFINER=`zsi`@`%` SQL SECURITY DEFINER VIEW `user_locations2_v` AS select '' AS `user_loc_id`,`b`.`loc_id` AS `loc_id`,'' AS `user_id`,`b`.`location` AS `location` from (`user_locations` `a` join `locations` `b`) where (`a`.`loc_id` = `b`.`loc_id`);

-- --------------------------------------------------------

--
-- Structure for view `user_locations_v`
--
DROP TABLE IF EXISTS `user_locations_v`;

CREATE ALGORITHM=UNDEFINED DEFINER=`zsi`@`%` SQL SECURITY DEFINER VIEW `user_locations_v` AS select `a`.`user_loc_id` AS `user_loc_id`,`a`.`loc_id` AS `loc_id`,`a`.`user_id` AS `user_id`,`b`.`location` AS `location` from (`user_locations` `a` join `locations` `b`) where (`a`.`loc_id` = `b`.`loc_id`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
