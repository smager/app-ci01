-- phpMyAdmin SQL Dump
-- version 4.4.6
-- http://www.phpmyadmin.net
--
-- Host: oracleexpertscebu.com
-- Generation Time: Oct 01, 2015 at 06:01 PM
-- Server version: 5.5.42-cll-lve
-- PHP Version: 5.4.16

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `zsi_sims`
--

DELIMITER $$
--
-- Procedures
--
$$

CREATE DEFINER=`zsi`@`%` PROCEDURE `delPC_Unposted`(IN p_loc_pc_id int(5))
BEGIN
   DELETE FROM loc_pc_dtls WHERE loc_pc_id = p_loc_pc_id;
   DELETE FROM loc_pc WHERE loc_pc_id = p_loc_pc_id;
END$$

CREATE DEFINER=`zsi`@`%` PROCEDURE `delPO_Unposted`(IN p_po_id int(5))
BEGIN
	DELETE FROM po_dtl WHERE po_id = po_id;
	DELETE FROM po WHERE po_id = p_po_id;
END$$

$$

CREATE DEFINER=`zsi`@`%` PROCEDURE `getDesc`(IN p_table VARCHAR(20), IN p_column VARCHAR(20), IN p_where VARCHAR(100))
BEGIN
    SET @sql=CONCAT("SELECT ", p_column, " FROM ", p_table, " ", p_where);
    PREPARE s1 FROM  @sql;
    execute s1;
    DEALLOCATE PREPARE s1;
END$$

$$

$$

CREATE DEFINER=`zsi`@`%` PROCEDURE `getLocPC_Unposted`(p_loc_id int(5))
BEGIN
select * from loc_pc where posted=0
and loc_id=p_loc_id;
END$$

$$

$$

$$

CREATE DEFINER=`zsi`@`%` PROCEDURE `getStoreDailyCash`(p_store_loc_id INT(10),p_date VARCHAR(20))
BEGIN
     SELECT *, getEmplName(empl_id) as empl_name, getEvent(event_id) as event_desc
       FROM store_daily_cash 
      WHERE store_loc_id =p_store_loc_id
        AND tran_date = str_to_date(p_date,'%m/%d/%Y');
END$$

CREATE DEFINER=`zsi`@`%` PROCEDURE `getStoreDailyCashById`(IN p_store_daily_cash_id INT(10))
BEGIN
     SELECT *, getEmplName(empl_id), getEvent(event_id) FROM store_daily_cash WHERE store_daily_cash_id =p_store_daily_cash_id;
END$$

CREATE DEFINER=`zsi`@`%` PROCEDURE `getStoreLocSupplies`(IN p_store_loc_id INT)
BEGIN
     SELECT * FROM store_loc_supplies_v WHERE store_loc_id =p_store_loc_id;
END$$

CREATE DEFINER=`zsi`@`%` PROCEDURE `getStoreLocSupplyDaily`(p_store_loc_id int(5), p_date VARCHAR(20))
BEGIN
select * from store_loc_supply_daily_v where store_loc_id = p_store_loc_id
and DATE_FORMAT(stock_date,'%m/%d/%Y') = p_date; 
END$$

$$

CREATE DEFINER=`zsi`@`%` PROCEDURE `getSupplyIsUnposted`(IN p_store_loc_id int, IN p_loc_supply_id int)
BEGIN
   DECLARE l_id INT(5);
   SELECT supply_is_id INTO l_id FROM supply_is WHERE posted=0 and store_loc_id = p_store_loc_id limit 1;
   IF IFNULL(l_id,0)=0 THEN
      SELECT *, "" as supply_is_id, "" as supply_is_dtl_id, "" as supply_is_qty FROM loc_supply_brands_v WHERE loc_id = getLocIdFromStoreLoc(p_store_loc_id) and loc_supply_id =p_loc_supply_id and stock_qty > 0 ;
   ELSE
    SELECT a.supply_is_id, a.supply_is_dtl_id, b.loc_supply_id,  a.loc_supply_brand_id, b.stock_qty, b.brand_name, b.cu_desc, a.supply_is_qty
       FROM supply_is_dtls a, loc_supply_brands_v b
       WHERE a.loc_supply_brand_id = b.loc_supply_brand_id and a.supply_is_id = l_id
       AND b.loc_supply_id =p_loc_supply_id
      UNION
      SELECT "" as supply_is_id, "" as supply_is_dtl_id, a.loc_supply_id, a.loc_supply_brand_id, a.stock_qty, a.brand_name, a.cu_desc, "" as supply_is_qty 
        FROM loc_supply_brands_v a 
       WHERE a.stock_qty > 0 AND a.loc_supply_id = p_loc_supply_id AND NOT EXISTS (SELECT b.loc_supply_brand_id FROM supply_is_dtls b 
       WHERE b.loc_supply_brand_id = b.loc_supply_brand_id and supply_is_id = l_id);   
   END IF;   
END$$

$$

CREATE DEFINER=`zsi`@`%` PROCEDURE `LocSupplyBrandsIns`(p_loc_id int(5))
BEGIN
INSERT INTO loc_supply_brands (supply_brand_id, loc_supply_id)
SELECT a.supply_brand_id, getLocSupplyId(p_loc_id, a.supply_id) 
FROM supply_brands a
WHERE NOT EXISTS (SELECT supply_brand_id FROM loc_supply_brands b WHERE b.loc_supply_id =  getLocSupplyId(p_loc_id, a.supply_id));
END$$

CREATE DEFINER=`zsi`@`%` PROCEDURE `LocSupplyBrandsIns2`(p_supply_id int(5))
BEGIN
DECLARE l_loc_id   int;
DECLARE l_loc_supply_id INT;
DECLARE exit_loop BOOLEAN;       
DECLARE loc_cursor CURSOR FOR
  SELECT loc_id FROM locations;
 
DECLARE CONTINUE HANDLER FOR NOT FOUND SET exit_loop = TRUE; 
OPEN loc_cursor;  
locations_loop: LOOP 
FETCH  loc_cursor INTO l_loc_id;
     SELECT loc_supply_id INTO l_loc_supply_id FROM loc_supplies WHERE loc_id = l_loc_id AND supply_id = p_supply_id;

     INSERT INTO loc_supply_brands (supply_brand_id, loc_supply_id)
     SELECT a.supply_brand_id, l_loc_supply_id
     FROM supply_brands a
     WHERE a.supply_id = p_supply_id
     AND NOT EXISTS (SELECT supply_brand_id FROM loc_supply_brands_v b WHERE a.supply_brand_id = b.supply_brand_id and b.loc_id=l_loc_id);
     IF exit_loop THEN
         CLOSE loc_cursor;
         LEAVE locations_loop;
     END IF;
   END LOOP locations_loop;

END$$

CREATE DEFINER=`zsi`@`%` PROCEDURE `loc_pc_post`(p_loc_pc_id int(5), p_date varchar(20))
BEGIN
DECLARE l_found VARCHAR(5);
      UPDATE loc_supply_brands a, loc_pc_dtls b 
      SET a.stock_qty = b.pc_qty
      WHERE a.loc_supply_brand_id = b.loc_supply_brand_id
      AND b.loc_pc_id = p_loc_pc_id;    
END$$

$$

$$

$$

$$

$$

$$

$$

$$

CREATE DEFINER=`zsi`@`%` PROCEDURE `setLocStockIsPost`(IN p_supply_is_id INT)
BEGIN
  UPDATE loc_supply_brands a, supply_is_dtls b
  SET a.stock_qty = a.stock_qty - b.supply_is_qty
  WHERE a.loc_supply_brand_id = b.loc_supply_brand_id
  AND b.supply_is_id = p_supply_is_id;
END$$

$$

$$

CREATE DEFINER=`zsi`@`%` PROCEDURE `setStoreDailyExpPosted`(p_store_loc_exp_id int(5), p_store_loc_id int(5), p_exp_date varchar(20))
BEGIN
  DECLARE l_date DATE;
  SET l_date = str_to_date(p_exp_date,'%m/%d/%Y');
  
  UPDATE store_daily_cash
  SET ttl_exp_amt = getExpenseSum(p_store_loc_id,l_date)
     ,ttl_sales_exp_amt =  getSalesExpenseSum(p_store_loc_id,l_date)
  WHERE store_loc_id=p_store_loc_id
    AND tran_date = l_date;
END$$

$$

$$

$$

CREATE DEFINER=`zsi`@`%` PROCEDURE `stock_transfer_post`(p_st_id int(5), p_loc_id_to int)
BEGIN
   UPDATE loc_supply_brands a, stock_transfer_dtls b
   SET a.stock_qty = a.stock_qty - b.st_qty
   WHERE st_id = p_st_id
   AND a.loc_supply_brand_id=b.loc_supply_brand_id;

   UPDATE loc_supply_brands_v a, stock_transfer_dtls b
   SET a.stock_qty = a.stock_qty + b.st_qty
   WHERE st_id = p_st_id
   AND a.supply_brand_id=getSupplyBrandIdFromLoc(b.loc_supply_brand_id)
   AND a.loc_id = p_loc_id_to;
END$$

CREATE DEFINER=`zsi`@`%` PROCEDURE `store_daily_cash_postedCB`(IN p_store_daily_cash_id int(5))
BEGIN
DECLARE l_cash_amt decimal(7,2);
DECLARE l_depo_amt decimal(7,2);
DECLARE l_fr_store_daily_cash_id INT;
DECLARE l_created_by INT;
DECLARE l_created_date DATE;
DECLARE l_store_bank_depo_id INT;

SELECT sum(IFNULL(cash_amount,0))
  INTO l_cash_amt
  FROM store_daily_cash_dtls 
 WHERE store_daily_cash_id=p_store_daily_cash_id;

UPDATE store_daily_cash 
   SET ttl_cash_box_amt   = l_cash_amt
 WHERE store_daily_cash_id=p_store_daily_cash_id;    

SELECT fr_store_daily_cash_id INTO l_fr_store_daily_cash_id
  FROM store_daily_cash 
 WHERE store_daily_cash_id=p_store_daily_cash_id;    

IF IFNULL(l_fr_store_daily_cash_id,0) <> 0 THEN

   SELECT depo_amt, created_by, created_date
     INTO l_depo_amt, l_created_by, l_created_date
     FROM store_daily_cash
    WHERE fr_store_daily_cash_id=l_fr_store_daily_cash_id;

   UPDATE store_daily_cash 
      SET depo_amt = ttl_return_amt - (l_cash_amt + IFNULL(ttl_exp_amt,0))
    WHERE fr_store_daily_cash_id=p_store_daily_cash_id;

   SELECT IFNULL(store_bank_depo_id,0) 
     INTO l_store_bank_depo_id
     FROM store_bank_depo        
    WHERE store_daily_cash_id=l_fr_store_daily_cash_id;    

   IF IFNULL(l_store_bank_depo_id,0)=0 THEN
      INSERT INTO store_bank_depo       
           (store_loc_id, sales_date, depo_amt, created_by, created_date) 
            SELECT store_loc_id, tran_date, depo_amt, created_by, created_date 
              FROM store_daily_cash    
             WHERE store_daily_cash_id=l_fr_store_daily_cash_id;   
   ELSE
      UPDATE store_bank_depo
         SET depo_amt= l_depo_amt,
             created_by=l_created_date,
             created_date=l_created_date
       WHERE store_bank_depo_id = l_store_bank_depo_id;

      DELETE FROM store_bank_depo_dtls WHERE store_bank_depo_id = l_store_bank_depo_id; 
   END IF;
END IF;
   UPDATE store_daily_cash a, store_loc b
      SET a.fr_store_daily_cash_id = b.last_posted_dcash
    WHERE a.store_loc_id = b.store_loc_id
      AND a.store_daily_cash_id=p_store_daily_cash_id;     
END$$

$$

CREATE DEFINER=`zsi`@`%` PROCEDURE `store_daily_cash_report`(p_store_loc_id int, p_tran_date varchar(20))
BEGIN
   SELECT *, get_store_daily_cash_denom_nextday_qty(store_daily_cash_id, denomination) as today_qty
   FROM store_daily_cash_dtls_v
   WHERE store_loc_id = p_store_loc_id AND tran_date = str_to_date(p_tran_date,'%m/%d/%Y');
END$$

CREATE DEFINER=`zsi`@`%` PROCEDURE `store_loc_exp_report`(p_store_loc_id int, p_tran_date varchar(20))
BEGIN
   SELECT *
   FROM store_loc_exp_dtls_v 
   WHERE store_loc_id = p_store_loc_id AND exp_date = str_to_date(p_tran_date,'%m/%d/%Y');
END$$

CREATE DEFINER=`zsi`@`%` PROCEDURE `store_loc_sales_exp_report`(p_store_loc_id int, p_tran_date varchar(20))
BEGIN
   SELECT *
   FROM store_loc_sales_exp_dtls_v 
   WHERE store_loc_id = p_store_loc_id AND exp_date = str_to_date(p_tran_date,'%m/%d/%Y');
END$$

$$

--
-- Functions
--
CREATE DEFINER=`zsi`@`%` FUNCTION `getBankName`(p_bank_ref_id int(5)) RETURNS varchar(100) CHARSET latin1
    DETERMINISTIC
BEGIN
    DECLARE lvl VARCHAR(100);
    SELECT bank_name INTO lvl FROM bank_ref WHERE bank_ref_id = p_bank_ref_id;
 RETURN (ifnull(lvl,''));
END$$

$$

$$

CREATE DEFINER=`zsi`@`%` FUNCTION `getExpenseSum`(p_store_loc_id int(5), p_date date) RETURNS decimal(7,2)
    DETERMINISTIC
BEGIN
 DECLARE lvl decimal(7,2);
    select SUM(exp_amt) INTO lvl from store_loc_exp_dtls_v where store_loc_id = p_store_loc_id
    and exp_date = p_date; 
 RETURN (ifnull(lvl,0));
END$$

CREATE DEFINER=`zsi`@`%` FUNCTION `getlatestrevid`(p_filename varchar(100)) RETURNS varchar(100) CHARSET latin1
    DETERMINISTIC
begin
   declare lvl varchar(100);
   select revision_id into lvl
   from revision_logs
   where filename=p_filename
   order by revision_id desc limit 1;
   return (lvl);
 end$$

CREATE DEFINER=`zsi`@`%` FUNCTION `getLocation`(p_loc_id int) RETURNS varchar(100) CHARSET latin1
    DETERMINISTIC
BEGIN
    DECLARE lvl varchar(100);
    SELECT location INTO lvl FROM locations WHERE loc_id=p_loc_id;
 RETURN (lvl);
END$$

$$

CREATE DEFINER=`zsi`@`%` FUNCTION `getLocIdFromStoreLoc`(p_store_loc_id int) RETURNS varchar(100) CHARSET latin1
    DETERMINISTIC
BEGIN
    DECLARE lvl int(5);
    SELECT loc_id INTO lvl FROM store_loc WHERE store_loc_id=p_store_loc_id;
 RETURN (lvl);
END$$

$$

CREATE DEFINER=`zsi`@`%` FUNCTION `getLocSupplyBrandId`(p_loc_id int, p_supply_id int, p_supply_brand_id int) RETURNS int(5)
    DETERMINISTIC
BEGIN
    DECLARE lvl int;
    SELECT loc_supply_brand_id INTO lvl FROM loc_supply_brands WHERE supply_brand_id=p_supply_brand_id 
       AND loc_supply_id=(select loc_supply_id FROM loc_supplies WHERE loc_id = p_loc_id and supply_id = p_supply_id); 
 RETURN (ifnull(lvl,0));
END$$

$$

CREATE DEFINER=`zsi`@`%` FUNCTION `getLocSupplyId`(p_loc_id int, p_supply_id int) RETURNS int(5)
    DETERMINISTIC
BEGIN
    DECLARE lvl int;
    SELECT loc_supply_id INTO lvl FROM loc_supplies WHERE loc_id = p_loc_id and supply_id = p_supply_id; 
 RETURN (ifnull(lvl,0));
END$$

$$

$$

CREATE DEFINER=`zsi`@`%` FUNCTION `getMenuType`(p_menu_type_id int) RETURNS varchar(100) CHARSET latin1
    DETERMINISTIC
BEGIN
    DECLARE lvl varchar(100);
    SELECT menu_type INTO lvl FROM menu_types WHERE menu_type_id=p_menu_type_id;
 RETURN (lvl);
END$$

CREATE DEFINER=`zsi`@`%` FUNCTION `getPOBalCount`(p_po_id int) RETURNS int(5)
    DETERMINISTIC
BEGIN
    DECLARE lvl int(5);
    SELECT COUNT(po_id) INTO lvl FROM po_dtls WHERE po_id=p_po_id and ifnull(bal_qty,0) > 0 ;
 RETURN (lvl);
END$$

$$

CREATE DEFINER=`zsi`@`%` FUNCTION `getPOLocId`(p_po_id int) RETURNS int(5)
    DETERMINISTIC
BEGIN
    DECLARE lvl varchar(100);
    SELECT loc_id INTO lvl FROM po WHERE po_id=p_po_id;
 RETURN (lvl);
END$$

CREATE DEFINER=`zsi`@`%` FUNCTION `getSalesExpenseSum`(p_store_loc_id int(5), p_date date) RETURNS decimal(7,2)
    DETERMINISTIC
BEGIN
 DECLARE lvl decimal(7,2);
    select SUM(exp_amt) INTO lvl from store_loc_sales_exp_dtls_v where store_loc_id = p_store_loc_id
    and exp_date = p_date; 
 RETURN (ifnull(lvl,0));
END$$

$$

CREATE DEFINER=`zsi`@`%` FUNCTION `getStockCount`(p_loc_supply_id int) RETURNS decimal(7,2)
    DETERMINISTIC
BEGIN
    DECLARE lvl decimal(7,2);
    SELECT sum(stock_qty) INTO lvl FROM loc_supply_brands WHERE loc_supply_id=p_loc_supply_id;
 RETURN (lvl);
END$$

$$

$$

$$

$$

$$

$$

$$

$$

$$

$$

$$

$$

CREATE DEFINER=`zsi`@`%` FUNCTION `getStoreLocSupplyBrandStockQty`(p_store_loc_id INT, p_loc_supply_brand_id INT) RETURNS decimal(7,2)
    DETERMINISTIC
BEGIN
    DECLARE lvl DECIMAL(7,2);
    SELECT stock_qty INTO lvl FROM store_loc_supply_brands_v WHERE store_loc_id = p_store_loc_id and loc_supply_brand_id = p_loc_supply_brand_id; 
 RETURN (ifnull(lvl,0));
END$$

$$

CREATE DEFINER=`zsi`@`%` FUNCTION `getStoreLocSupplyId`(p_store_loc_id int, p_loc_supply_id int) RETURNS int(5)
    DETERMINISTIC
BEGIN
    DECLARE lvl int(5);
    SELECT store_loc_supply_id INTO lvl FROM store_loc_supplies WHERE store_loc_id=p_store_loc_id and loc_supply_id=p_loc_supply_id;
 RETURN (lvl);
END$$

CREATE DEFINER=`zsi`@`%` FUNCTION `getStoreLocTotalStocks`(p_store_loc_supply_id int) RETURNS decimal(7,2)
    DETERMINISTIC
BEGIN
    DECLARE lvl decimal(7,2);
    SELECT ttl_stocks INTO lvl FROM StoreLocSupplyBrandsSum_v WHERE store_loc_supply_id=p_store_loc_supply_id;
 RETURN (ifnull(lvl,0));
END$$

CREATE DEFINER=`zsi`@`%` FUNCTION `getSupplier`(p_supplier_id int) RETURNS varchar(100) CHARSET latin1
    DETERMINISTIC
BEGIN
    DECLARE lvl varchar(100);
    SELECT supplier_name INTO lvl FROM suppliers WHERE supplier_id=p_supplier_id;
 RETURN (lvl);
END$$

CREATE DEFINER=`zsi`@`%` FUNCTION `getSupplierByStore`(p_store_id int) RETURNS varchar(100) CHARSET latin1
    DETERMINISTIC
BEGIN
    DECLARE lvl varchar(100);
    SELECT getSupplier(supplier_id) as supplier_name INTO lvl FROM stores WHERE store_id=store_id;
 RETURN (lvl);
END$$

CREATE DEFINER=`zsi`@`%` FUNCTION `getSupplierIdByStore`(p_store_id int) RETURNS int(5)
    DETERMINISTIC
BEGIN
    DECLARE lvl INT(5);
    SELECT supplier_id as supplier_name INTO lvl FROM stores WHERE store_id=p_store_id;
 RETURN (lvl);
END$$

CREATE DEFINER=`zsi`@`%` FUNCTION `getSupplyBrandIdFromLoc`(p_loc_supply_brand_id int) RETURNS int(5)
    DETERMINISTIC
BEGIN
    DECLARE lvl int;
    SELECT supply_brand_id INTO lvl FROM loc_supply_brands_v WHERE loc_supply_brand_id=p_loc_supply_brand_id;
 RETURN (ifnull(lvl,0));
END$$

$$

CREATE DEFINER=`zsi`@`%` FUNCTION `getSupplyIdFromLoc`(p_loc_supply_id int) RETURNS int(5)
    DETERMINISTIC
BEGIN
    DECLARE lvl int;
    SELECT supply_id INTO lvl FROM loc_supplies WHERE loc_supply_id = p_loc_supply_id; 
 RETURN (ifnull(lvl,0));
END$$

$$

CREATE DEFINER=`zsi`@`%` FUNCTION `getSupplyType`(p_supply_type_id int) RETURNS varchar(100) CHARSET latin1
    DETERMINISTIC
BEGIN
    DECLARE lvl varchar(100);
    SELECT supply_type INTO lvl FROM supply_types WHERE supply_type_id=p_supply_type_id;
 RETURN (lvl);
END$$

CREATE DEFINER=`zsi`@`%` FUNCTION `getSupplyUcost`(p_supply_id int) RETURNS decimal(7,2)
    DETERMINISTIC
BEGIN
    DECLARE lvl decimal(7,2);
    SELECT supply_cost INTO lvl FROM supplies WHERE supply_id=p_supply_id;
 RETURN (lvl);
END$$

CREATE DEFINER=`zsi`@`%` FUNCTION `getSupplyUcostByBrandUnit`(p_supply_brand_id int) RETURNS decimal(7,2)
    DETERMINISTIC
BEGIN
    DECLARE lvl decimal(7,2);
    SELECT supply_cost INTO lvl FROM supply_brands WHERE supply_brand_id=p_supply_brand_id;
 RETURN (lvl);
END$$

CREATE DEFINER=`zsi`@`%` FUNCTION `getSupplyUprice`(p_supply_id int) RETURNS decimal(7,2)
    DETERMINISTIC
BEGIN
    DECLARE lvl decimal(7,2);
    SELECT supply_srp INTO lvl FROM supplies WHERE supply_id=p_supply_id;
 RETURN (lvl);
END$$

CREATE DEFINER=`zsi`@`%` FUNCTION `getToCashBoxAmount`(p_store_daily_cash_id int(5)) RETURNS decimal(7,2)
    DETERMINISTIC
BEGIN
 DECLARE lvl decimal(7,2);
    select ttl_cash_box_amt INTO lvl from store_daily_cash where fr_store_daily_cash_id = p_store_daily_cash_id;
 RETURN (ifnull(lvl,0));
END$$

$$

CREATE DEFINER=`zsi`@`%` FUNCTION `get_store_daily_cash_denom_amt`(p_store_loc_id int,  p_denomination int, p_tran_date DATE) RETURNS int(5)
    DETERMINISTIC
BEGIN
    DECLARE lvl INT(5);
    SELECT cash_amount INTO lvl FROM store_daily_cash_dtls_v WHERE store_loc_id = p_store_loc_id and denomination=p_denomination AND  tran_date = p_tran_date; 
 RETURN (ifnull(lvl,0));
END$$

CREATE DEFINER=`zsi`@`%` FUNCTION `get_store_daily_cash_denom_nextday_qty`(p_store_daily_cash_id int, p_denomination int) RETURNS int(5)
    DETERMINISTIC
BEGIN
    DECLARE lvl INT(5);
    SELECT denomination_qty INTO lvl FROM store_daily_cash_dtls_v WHERE fr_store_daily_cash_id=p_store_daily_cash_id and denomination=p_denomination; 
 RETURN (ifnull(lvl,0));
END$$

CREATE DEFINER=`zsi`@`%` FUNCTION `get_store_daily_cash_denom_qty`(p_store_loc_id int,  p_denomination int, p_tran_date DATE) RETURNS int(5)
    DETERMINISTIC
BEGIN
    DECLARE lvl INT(5);
    SELECT denomination_qty INTO lvl FROM store_daily_cash_dtls_v WHERE store_loc_id = p_store_loc_id and denomination=p_denomination AND  tran_date = p_tran_date; 
 RETURN (ifnull(lvl,0));
END$$

CREATE DEFINER=`zsi`@`%` FUNCTION `get_store_pc_qty`(p_store_loc_id int,  p_loc_supply_brand_id int, p_tran_date DATE) RETURNS decimal(7,2)
    DETERMINISTIC
BEGIN
    DECLARE lvl decimal(7,2);
    SELECT pc_qty INTO lvl FROM loc_pc_dtls_v WHERE store_loc_id = p_store_loc_id and loc_supply_brand_id=p_loc_supply_brand_id AND  DATE_FORMAT(pc_date,'%m/%d/%Y') = p_tran_date; 
 RETURN (ifnull(lvl,0));
END$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `add_on_rate`
--

CREATE TABLE IF NOT EXISTS `add_on_rate` (
  `holiday_pct` decimal(5,2) DEFAULT NULL,
  `sunday_pct` decimal(5,2) DEFAULT NULL,
  `created_by` int(5) DEFAULT NULL,
  `created_date` datetime DEFAULT NULL,
  `updated_by` int(5) DEFAULT NULL,
  `updated_date` datetime DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Add on pct rate Reference';

-- --------------------------------------------------------

--
-- Table structure for table `adjustments_ref`
--

CREATE TABLE IF NOT EXISTS `adjustments_ref` (
  `adjmt_id` int(5) unsigned NOT NULL,
  `adjmt_desc` varchar(20) COLLATE utf8_bin NOT NULL DEFAULT '',
  `posted` int(5) NOT NULL DEFAULT '0',
  `created_by` int(5) DEFAULT NULL,
  `created_date` datetime DEFAULT NULL,
  `updated_by` int(5) DEFAULT NULL,
  `updated_date` datetime DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Supply Adjustment';

-- --------------------------------------------------------

--
-- Table structure for table `bank_ref`
--

CREATE TABLE IF NOT EXISTS `bank_ref` (
  `bank_ref_id` int(5) unsigned NOT NULL,
  `bank_acctno` varchar(30) COLLATE utf8_bin NOT NULL DEFAULT '',
  `bank_acctname` varchar(50) COLLATE utf8_bin NOT NULL DEFAULT '',
  `bank_name` varchar(50) COLLATE utf8_bin NOT NULL DEFAULT '',
  `acct_amount` decimal(10,2) DEFAULT NULL,
  `depo_pct_share` int(5) DEFAULT NULL,
  `priority_no` int(5) DEFAULT NULL,
  `active` int(5) NOT NULL DEFAULT '1',
  `created_by` int(5) DEFAULT NULL,
  `created_date` datetime DEFAULT NULL,
  `updated_by` int(5) DEFAULT NULL,
  `updated_date` datetime DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Bank Accounts Reference';

-- --------------------------------------------------------

--
-- Table structure for table `brands`
--

CREATE TABLE IF NOT EXISTS `brands` (
  `brand_id` int(5) unsigned NOT NULL,
  `brand_name` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `created_by` int(5) DEFAULT NULL,
  `created_date` datetime DEFAULT NULL,
  `updated_by` int(5) DEFAULT NULL,
  `updated_date` datetime DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Brands';

-- --------------------------------------------------------

--
-- Table structure for table `console_logs`
--

CREATE TABLE IF NOT EXISTS `console_logs` (
  `console_log_id` int(11) NOT NULL,
  `content` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `conv_units`
--

CREATE TABLE IF NOT EXISTS `conv_units` (
  `conv_id` int(5) unsigned NOT NULL,
  `from_unit_id` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `conv_unit_id` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `conv_unit_qty` decimal(5,2) DEFAULT NULL,
  `created_by` int(5) DEFAULT NULL,
  `created_date` datetime DEFAULT NULL,
  `updated_by` int(5) DEFAULT NULL,
  `updated_date` datetime DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Unit of Measures Conversions';

-- --------------------------------------------------------

--
-- Table structure for table `dbstructures`
--

CREATE TABLE IF NOT EXISTS `dbstructures` (
  `dbstruct_id` int(11) NOT NULL,
  `object_name` varchar(50) NOT NULL,
  `object_type` varchar(15) NOT NULL,
  `seq_no` int(11) DEFAULT NULL,
  `content` text NOT NULL,
  `created_by` int(11) DEFAULT NULL,
  `created_date` datetime DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  `updated_date` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `deductions_ref`
--

CREATE TABLE IF NOT EXISTS `deductions_ref` (
  `deduction_ref_id` int(5) unsigned NOT NULL,
  `deduction_code` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `deduction_desc` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `deduction_pct` decimal(7,2) DEFAULT NULL,
  `default_amt` decimal(7,2) DEFAULT NULL,
  `created_by` int(5) DEFAULT NULL,
  `created_date` datetime DEFAULT NULL,
  `updated_by` int(5) DEFAULT NULL,
  `updated_date` datetime DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Deductions Reference file';

-- --------------------------------------------------------

--
-- Table structure for table `denomination_ref`
--

CREATE TABLE IF NOT EXISTS `denomination_ref` (
  `denomination` decimal(7,2) NOT NULL DEFAULT '0.00',
  `created_by` int(5) DEFAULT NULL,
  `created_date` datetime DEFAULT NULL,
  `updated_by` int(5) DEFAULT NULL,
  `updated_date` datetime DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Money Denomination Reference';

-- --------------------------------------------------------

--
-- Table structure for table `employees`
--

CREATE TABLE IF NOT EXISTS `employees` (
  `empl_id` int(5) unsigned NOT NULL,
  `empl_idno` varchar(10) COLLATE utf8_bin NOT NULL DEFAULT '',
  `empl_name` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `loc_id` int(5) DEFAULT NULL,
  `store_loc_id` int(5) DEFAULT NULL,
  `position_id` int(5) DEFAULT NULL,
  `daily_rate` decimal(7,2) DEFAULT NULL,
  `sss_no` varchar(20) COLLATE utf8_bin DEFAULT NULL,
  `pagibig_no` varchar(20) COLLATE utf8_bin DEFAULT NULL,
  `tin` varchar(20) COLLATE utf8_bin DEFAULT NULL,
  `philhealth_no` varchar(20) COLLATE utf8_bin DEFAULT NULL,
  `civil_status` varchar(20) COLLATE utf8_bin DEFAULT NULL,
  `active` int(5) NOT NULL DEFAULT '1',
  `created_by` int(5) DEFAULT NULL,
  `created_date` datetime DEFAULT NULL,
  `updated_by` int(5) DEFAULT NULL,
  `updated_date` datetime DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Employees';

-- --------------------------------------------------------

--
-- Table structure for table `events`
--

CREATE TABLE IF NOT EXISTS `events` (
  `event_id` int(5) unsigned NOT NULL,
  `event_desc` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `created_by` int(5) DEFAULT NULL,
  `created_date` datetime DEFAULT NULL,
  `updated_by` int(5) DEFAULT NULL,
  `updated_date` datetime DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Events reference';

-- --------------------------------------------------------

--
-- Table structure for table `inv_summ`
--

CREATE TABLE IF NOT EXISTS `inv_summ` (
  `inv_summ_id` int(5) unsigned NOT NULL,
  `inv_summ_year` int(5) DEFAULT NULL,
  `inv_summ_month` int(5) DEFAULT NULL,
  `loc_id` int(5) DEFAULT NULL,
  `supply_id` int(5) DEFAULT NULL,
  `beg_qty` decimal(10,2) DEFAULT NULL,
  `dr_qty` decimal(10,2) DEFAULT NULL,
  `used_qty` decimal(10,2) DEFAULT NULL,
  `adj_plus_qty` decimal(10,2) DEFAULT NULL,
  `adj_minus_qty` decimal(10,2) DEFAULT NULL,
  `end_qty` decimal(10,2) DEFAULT NULL,
  `created_by` int(5) DEFAULT NULL,
  `created_date` datetime DEFAULT NULL,
  `updated_by` int(5) DEFAULT NULL,
  `updated_date` datetime DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Inventory Summary';

-- --------------------------------------------------------

--
-- Table structure for table `javascripts`
--

CREATE TABLE IF NOT EXISTS `javascripts` (
  `js_id` int(11) NOT NULL,
  `version_id` int(11) DEFAULT NULL,
  `page_url` varchar(100) NOT NULL,
  `content` text NOT NULL,
  `created_by` int(11) DEFAULT NULL,
  `created_date` datetime DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  `updated_date` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `locations`
--

CREATE TABLE IF NOT EXISTS `locations` (
  `loc_id` int(5) unsigned NOT NULL,
  `location` varchar(100) COLLATE utf8_bin NOT NULL DEFAULT '',
  `created_by` int(5) DEFAULT NULL,
  `created_date` datetime DEFAULT NULL,
  `updated_by` int(5) DEFAULT NULL,
  `updated_date` datetime DEFAULT NULL,
  `loc_group_id` int(5) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Locations';

--
-- Triggers `locations`
--
DELIMITER $$
CREATE TRIGGER `loc_supplies_t` AFTER INSERT ON `locations`
 FOR EACH ROW BEGIN
    INSERT INTO loc_supplies (loc_id, supply_id, created_by, created_date) 
           SELECT  NEW.loc_id, supply_id, NEW.created_by, NOW() FROM supplies;
  END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `loc_pc`
--

CREATE TABLE IF NOT EXISTS `loc_pc` (
  `loc_pc_id` int(5) unsigned NOT NULL,
  `pc_no` int(5) DEFAULT NULL,
  `pc_date` datetime DEFAULT NULL,
  `loc_id` int(5) DEFAULT NULL,
  `posted` int(5) NOT NULL DEFAULT '0',
  `created_by` int(5) DEFAULT NULL,
  `created_date` datetime DEFAULT NULL,
  `updated_by` int(5) DEFAULT NULL,
  `updated_date` datetime DEFAULT NULL,
  `store_loc_id` int(5) DEFAULT NULL,
  `store_id` int(5) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Stock Physical Count header per location';

-- --------------------------------------------------------

--
-- Table structure for table `loc_pc_dtls`
--

CREATE TABLE IF NOT EXISTS `loc_pc_dtls` (
  `loc_pc_dtl_id` int(5) unsigned NOT NULL,
  `loc_pc_id` int(5) DEFAULT NULL,
  `loc_supply_brand_id` int(5) DEFAULT NULL,
  `store_loc_supply_id` int(5) DEFAULT NULL,
  `pc_qty` decimal(7,2) DEFAULT NULL,
  `created_by` int(5) DEFAULT NULL,
  `created_date` datetime DEFAULT NULL,
  `updated_by` int(5) DEFAULT NULL,
  `updated_date` datetime DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Stock Physical Count details per location';

-- --------------------------------------------------------

--
-- Table structure for table `loc_supplies`
--

CREATE TABLE IF NOT EXISTS `loc_supplies` (
  `loc_supply_id` int(5) unsigned NOT NULL,
  `loc_id` int(5) DEFAULT NULL,
  `supply_id` int(5) DEFAULT NULL,
  `reorder_level` int(5) DEFAULT NULL,
  `max_level` int(5) DEFAULT NULL,
  `created_by` int(5) DEFAULT NULL,
  `created_date` datetime DEFAULT NULL,
  `updated_by` int(5) DEFAULT NULL,
  `updated_date` datetime DEFAULT NULL,
  `ordered_qty` int(5) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Location Supplies';

-- --------------------------------------------------------

--
-- Table structure for table `loc_supply_brands`
--

CREATE TABLE IF NOT EXISTS `loc_supply_brands` (
  `loc_supply_brand_id` int(5) unsigned NOT NULL,
  `loc_supply_id` int(5) DEFAULT NULL,
  `supply_brand_id` int(5) DEFAULT NULL,
  `stock_qty` decimal(10,2) DEFAULT NULL,
  `created_by` int(5) DEFAULT NULL,
  `created_date` datetime DEFAULT NULL,
  `updated_by` int(5) DEFAULT NULL,
  `updated_date` datetime DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Location Supplies per brand';

-- --------------------------------------------------------

--
-- Table structure for table `menu`
--

CREATE TABLE IF NOT EXISTS `menu` (
  `menu_id` int(5) unsigned NOT NULL,
  `menu_name` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `menu_url` varchar(100) COLLATE utf8_bin NOT NULL DEFAULT '',
  `menu_type_id` int(5) DEFAULT NULL,
  `system_id` int(5) DEFAULT NULL,
  `seq_no` int(5) DEFAULT NULL,
  `created_by` int(5) DEFAULT NULL,
  `created_date` datetime DEFAULT NULL,
  `updated_by` int(5) DEFAULT NULL,
  `updated_date` datetime DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Menu';

-- --------------------------------------------------------

--
-- Table structure for table `menu_types`
--

CREATE TABLE IF NOT EXISTS `menu_types` (
  `menu_type_id` int(5) unsigned NOT NULL,
  `menu_type` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `seq_no` int(5) DEFAULT NULL,
  `created_by` int(5) DEFAULT NULL,
  `created_date` datetime DEFAULT NULL,
  `updated_by` int(5) DEFAULT NULL,
  `updated_date` datetime DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Menu Types';

-- --------------------------------------------------------

--
-- Table structure for table `months`
--

CREATE TABLE IF NOT EXISTS `months` (
  `month_id` int(5) NOT NULL,
  `month_fletter` varchar(1) NOT NULL,
  `month_sdesc` varchar(3) NOT NULL,
  `month_ldesc` varchar(15) NOT NULL,
  `created_by` int(11) DEFAULT NULL,
  `created_date` datetime DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  `updated_date` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `page_templates`
--

CREATE TABLE IF NOT EXISTS `page_templates` (
  `page_template_id` int(11) NOT NULL,
  `page_url` varchar(100) NOT NULL,
  `content` text NOT NULL,
  `created_by` int(11) DEFAULT NULL,
  `created_date` datetime DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  `updated_date` datetime DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `po`
--

CREATE TABLE IF NOT EXISTS `po` (
  `po_id` int(5) unsigned NOT NULL,
  `po_no` int(5) DEFAULT NULL,
  `po_date` datetime DEFAULT NULL,
  `loc_id` int(5) DEFAULT NULL,
  `supplier_id` int(5) DEFAULT NULL,
  `posted` int(5) NOT NULL DEFAULT '0',
  `created_by` int(5) DEFAULT NULL,
  `created_date` datetime DEFAULT NULL,
  `updated_by` int(5) DEFAULT NULL,
  `updated_date` datetime DEFAULT NULL,
  `status_code` varchar(1) COLLATE utf8_bin DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='order header';

-- --------------------------------------------------------

--
-- Table structure for table `positions`
--

CREATE TABLE IF NOT EXISTS `positions` (
  `position_id` int(5) unsigned NOT NULL,
  `position_desc` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `created_by` int(5) DEFAULT NULL,
  `created_date` datetime DEFAULT NULL,
  `updated_by` int(5) DEFAULT NULL,
  `updated_date` datetime DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Positions';

-- --------------------------------------------------------

--
-- Table structure for table `po_dtls`
--

CREATE TABLE IF NOT EXISTS `po_dtls` (
  `po_dtl_id` int(5) unsigned NOT NULL,
  `po_id` int(5) DEFAULT NULL,
  `loc_supply_id` int(5) DEFAULT NULL,
  `po_qty` decimal(10,2) DEFAULT NULL,
  `bal_qty` decimal(10,2) DEFAULT NULL,
  `unit_id` int(5) DEFAULT NULL,
  `created_by` int(5) DEFAULT NULL,
  `created_date` datetime DEFAULT NULL,
  `updated_by` int(5) DEFAULT NULL,
  `updated_date` datetime DEFAULT NULL,
  `cancelled_qty` decimal(7,0) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='orders details';

-- --------------------------------------------------------

--
-- Table structure for table `receiving`
--

CREATE TABLE IF NOT EXISTS `receiving` (
  `receiving_id` int(5) unsigned NOT NULL,
  `dr_no` int(5) DEFAULT NULL,
  `dr_date` datetime DEFAULT NULL,
  `po_id` int(5) DEFAULT NULL,
  `posted` int(5) NOT NULL DEFAULT '0',
  `created_by` int(5) DEFAULT NULL,
  `created_date` datetime DEFAULT NULL,
  `updated_by` int(5) DEFAULT NULL,
  `updated_date` datetime DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Receiving of orders header';

-- --------------------------------------------------------

--
-- Table structure for table `receiving_dtls`
--

CREATE TABLE IF NOT EXISTS `receiving_dtls` (
  `receiving_dtl_id` int(5) unsigned NOT NULL,
  `receiving_id` int(5) DEFAULT NULL,
  `po_dtl_id` int(5) DEFAULT NULL,
  `supply_brand_id` int(5) DEFAULT NULL,
  `dr_qty` decimal(10,2) DEFAULT NULL,
  `bal_qty` decimal(10,2) DEFAULT NULL,
  `created_by` int(5) DEFAULT NULL,
  `created_date` datetime DEFAULT NULL,
  `updated_by` int(5) DEFAULT NULL,
  `updated_date` datetime DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Receving of orders details';

-- --------------------------------------------------------

--
-- Table structure for table `revision_logs`
--

CREATE TABLE IF NOT EXISTS `revision_logs` (
  `revision_id` int(11) NOT NULL,
  `path` varchar(100) NOT NULL,
  `filename` varchar(50) NOT NULL,
  `filetype` varchar(50) NOT NULL,
  `content` text NOT NULL,
  `created_by` int(11) DEFAULT NULL,
  `created_date` datetime DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  `updated_date` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `roles`
--

CREATE TABLE IF NOT EXISTS `roles` (
  `role_id` int(5) unsigned NOT NULL,
  `role_desc` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `created_by` int(5) DEFAULT NULL,
  `created_date` datetime DEFAULT NULL,
  `updated_by` int(5) DEFAULT NULL,
  `updated_date` datetime DEFAULT NULL,
  `role_code` varchar(5) COLLATE utf8_bin DEFAULT NULL,
  `view_sales` int(1) DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Menus';

-- --------------------------------------------------------

--
-- Table structure for table `role_menus`
--

CREATE TABLE IF NOT EXISTS `role_menus` (
  `role_menu_id` int(5) unsigned NOT NULL,
  `menu_id` int(5) DEFAULT NULL,
  `role_id` int(5) DEFAULT NULL,
  `created_by` int(5) DEFAULT NULL,
  `created_date` datetime DEFAULT NULL,
  `updated_by` int(5) DEFAULT NULL,
  `updated_date` datetime DEFAULT NULL,
  `allow_unpost` int(1) DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='role_menus';

-- --------------------------------------------------------

--
-- Table structure for table `role_procs`
--

CREATE TABLE IF NOT EXISTS `role_procs` (
  `role_proc_id` int(5) unsigned NOT NULL,
  `proc_id` int(5) DEFAULT NULL,
  `role_id` int(5) DEFAULT NULL,
  `allow_write` int(5) NOT NULL DEFAULT '0',
  `created_by` int(5) DEFAULT NULL,
  `created_date` datetime DEFAULT NULL,
  `updated_by` int(5) DEFAULT NULL,
  `updated_date` datetime DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Role Procedure Access';

-- --------------------------------------------------------

--
-- Table structure for table `sales_summ`
--

CREATE TABLE IF NOT EXISTS `sales_summ` (
  `sales_summ_id` int(5) unsigned NOT NULL,
  `sales_summ_year` int(5) DEFAULT NULL,
  `sales_summ_month` int(5) DEFAULT NULL,
  `store_loc_id` int(5) DEFAULT NULL,
  `sales_amount` decimal(10,2) DEFAULT NULL,
  `created_by` int(5) DEFAULT NULL,
  `created_date` datetime DEFAULT NULL,
  `updated_by` int(5) DEFAULT NULL,
  `updated_date` datetime DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Store Sales Summary';

-- --------------------------------------------------------

--
-- Table structure for table `sales_supply_summ`
--

CREATE TABLE IF NOT EXISTS `sales_supply_summ` (
  `sales_supply_id` int(5) unsigned NOT NULL,
  `sales_supply_year` int(5) DEFAULT NULL,
  `sales_supply_month` int(5) DEFAULT NULL,
  `store_loc_id` int(5) DEFAULT NULL,
  `supply_id` int(5) DEFAULT NULL,
  `sales_amount` decimal(10,2) DEFAULT NULL,
  `created_by` int(5) DEFAULT NULL,
  `created_date` datetime DEFAULT NULL,
  `updated_by` int(5) DEFAULT NULL,
  `updated_date` datetime DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Store Sales Summary per Supply';

-- --------------------------------------------------------

--
-- Table structure for table `select_options`
--

CREATE TABLE IF NOT EXISTS `select_options` (
  `select_id` int(11) NOT NULL,
  `code` varchar(100) NOT NULL,
  `table_name` varchar(100) NOT NULL,
  `text` varchar(100) NOT NULL,
  `value` varchar(100) NOT NULL,
  `condition_text` varchar(100) DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `created_date` datetime DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  `updated_date` datetime DEFAULT NULL,
  `order_by` varchar(500) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `stock_adjustments`
--

CREATE TABLE IF NOT EXISTS `stock_adjustments` (
  `stock_adjmt_id` int(5) unsigned NOT NULL,
  `stock_adjmt_no` int(5) DEFAULT NULL,
  `adjmt_date` datetime DEFAULT NULL,
  `loc_id` int(5) DEFAULT NULL,
  `store_loc_id` int(5) DEFAULT NULL,
  `adjmt_id` int(5) DEFAULT NULL,
  `adjmt_remarks` varchar(200) COLLATE utf8_bin NOT NULL DEFAULT '',
  `loc_supply_brand_id` int(5) DEFAULT NULL,
  `store_loc_supply_daily_id` int(5) DEFAULT NULL,
  `curr_qty` decimal(5,2) DEFAULT NULL,
  `adjmt_qty` decimal(5,2) DEFAULT NULL,
  `diff_qty` decimal(5,2) DEFAULT NULL,
  `posted` int(5) NOT NULL DEFAULT '0',
  `created_by` int(5) DEFAULT NULL,
  `created_date` datetime DEFAULT NULL,
  `updated_by` int(5) DEFAULT NULL,
  `updated_date` datetime DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Stock Adjustment';

-- --------------------------------------------------------

--
-- Table structure for table `stock_transfer`
--

CREATE TABLE IF NOT EXISTS `stock_transfer` (
  `st_id` int(5) unsigned NOT NULL,
  `st_no` int(5) DEFAULT NULL,
  `st_date` datetime DEFAULT NULL,
  `loc_id` int(5) DEFAULT NULL,
  `loc_id_to` int(5) DEFAULT NULL,
  `posted` int(5) NOT NULL DEFAULT '0',
  `created_by` int(5) DEFAULT NULL,
  `created_date` datetime DEFAULT NULL,
  `updated_by` int(5) DEFAULT NULL,
  `updated_date` datetime DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Stock Transfer header to other warehouse';

-- --------------------------------------------------------

--
-- Table structure for table `stock_transfer_dtls`
--

CREATE TABLE IF NOT EXISTS `stock_transfer_dtls` (
  `st_dtl_id` int(5) unsigned NOT NULL,
  `st_id` int(5) DEFAULT NULL,
  `st_qty` decimal(7,2) DEFAULT NULL,
  `loc_supply_brand_id` int(5) DEFAULT NULL,
  `created_by` int(5) DEFAULT NULL,
  `created_date` datetime DEFAULT NULL,
  `updated_by` int(5) DEFAULT NULL,
  `updated_date` datetime DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Stock Transfer details to other warehouse';

-- --------------------------------------------------------

--
-- Table structure for table `stores`
--

CREATE TABLE IF NOT EXISTS `stores` (
  `store_id` int(5) unsigned NOT NULL,
  `store_name` varchar(100) COLLATE utf8_bin NOT NULL DEFAULT '',
  `created_by` int(5) DEFAULT NULL,
  `created_date` datetime DEFAULT NULL,
  `updated_by` int(5) DEFAULT NULL,
  `updated_date` datetime DEFAULT NULL,
  `supplier_id` int(5) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='stores';

-- --------------------------------------------------------

--
-- Table structure for table `store_bank_depo`
--

CREATE TABLE IF NOT EXISTS `store_bank_depo` (
  `store_bank_depo_id` int(5) unsigned NOT NULL,
  `store_loc_id` int(5) DEFAULT NULL,
  `sales_date` datetime DEFAULT NULL,
  `act_depo_date` datetime DEFAULT NULL,
  `depo_amt` decimal(7,2) DEFAULT NULL,
  `posted` int(5) NOT NULL DEFAULT '0',
  `created_by` int(5) DEFAULT NULL,
  `created_date` datetime DEFAULT NULL,
  `updated_by` int(5) DEFAULT NULL,
  `updated_date` datetime DEFAULT NULL,
  `depo_by_empl_id` int(5) DEFAULT NULL,
  `store_daily_cash_id` int(5) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Store Bank Deposits';

-- --------------------------------------------------------

--
-- Table structure for table `store_bank_depo_dtls`
--

CREATE TABLE IF NOT EXISTS `store_bank_depo_dtls` (
  `store_bank_depo_dtl_id` int(5) unsigned NOT NULL,
  `store_bank_depo_id` int(5) DEFAULT NULL,
  `bank_ref_id` int(5) DEFAULT NULL,
  `depo_pct_share` int(5) DEFAULT NULL,
  `depo_amount` decimal(7,2) DEFAULT NULL,
  `created_by` int(5) DEFAULT NULL,
  `created_date` datetime DEFAULT NULL,
  `updated_by` int(5) DEFAULT NULL,
  `updated_date` datetime DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Store Bank Deposits Details';

-- --------------------------------------------------------

--
-- Table structure for table `store_bank_depo_summ`
--

CREATE TABLE IF NOT EXISTS `store_bank_depo_summ` (
  `bank_depo_summ_id` int(5) unsigned NOT NULL,
  `bank_depo_summ_year` int(5) DEFAULT NULL,
  `bank_depo_summ_month` int(5) DEFAULT NULL,
  `bank_ref_id` int(5) DEFAULT NULL,
  `store_loc_id` int(5) DEFAULT NULL,
  `depo_amount` decimal(10,2) DEFAULT NULL,
  `created_by` int(5) DEFAULT NULL,
  `created_date` datetime DEFAULT NULL,
  `updated_by` int(5) DEFAULT NULL,
  `updated_date` datetime DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Store Bank Deposits Summary';

-- --------------------------------------------------------

--
-- Table structure for table `store_bank_wd`
--

CREATE TABLE IF NOT EXISTS `store_bank_wd` (
  `store_bank_wd_id` int(5) unsigned NOT NULL,
  `store_loc_id` int(5) DEFAULT NULL,
  `bank_ref_id` int(5) DEFAULT NULL,
  `tran_no` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `cheque_no` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `wd_date` datetime DEFAULT NULL,
  `wd_amount` decimal(7,2) DEFAULT NULL,
  `posted` int(5) NOT NULL DEFAULT '0',
  `created_by` int(5) DEFAULT NULL,
  `created_date` datetime DEFAULT NULL,
  `updated_by` int(5) DEFAULT NULL,
  `updated_date` datetime DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Store Bank Withdraws';

-- --------------------------------------------------------

--
-- Table structure for table `store_bank_wd_summ`
--

CREATE TABLE IF NOT EXISTS `store_bank_wd_summ` (
  `bank_wd_summ_id` int(5) unsigned NOT NULL,
  `bank_wd_summ_year` int(5) DEFAULT NULL,
  `bank_wd_summ_month` int(5) DEFAULT NULL,
  `bank_ref_id` int(5) DEFAULT NULL,
  `store_loc_id` int(5) DEFAULT NULL,
  `wd_amount` decimal(10,2) DEFAULT NULL,
  `created_by` int(5) DEFAULT NULL,
  `created_date` datetime DEFAULT NULL,
  `updated_by` int(5) DEFAULT NULL,
  `updated_date` datetime DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Store Bank Withdrawal Summary';

-- --------------------------------------------------------

--
-- Table structure for table `store_daily_cash`
--

CREATE TABLE IF NOT EXISTS `store_daily_cash` (
  `store_daily_cash_id` int(5) unsigned NOT NULL,
  `store_loc_id` int(5) DEFAULT NULL,
  `tran_date` datetime DEFAULT NULL,
  `ttl_cash_box_amt` decimal(7,2) DEFAULT NULL,
  `ttl_return_amt` decimal(7,2) DEFAULT NULL,
  `ttl_cash_sales_amt` decimal(7,2) DEFAULT NULL,
  `posted_dcash` int(5) NOT NULL DEFAULT '0',
  `posted_dsales` int(5) NOT NULL DEFAULT '0',
  `created_by` int(5) DEFAULT NULL,
  `created_date` datetime DEFAULT NULL,
  `updated_by` int(5) DEFAULT NULL,
  `updated_date` datetime DEFAULT NULL,
  `ttl_stock_sales_amt` decimal(7,2) DEFAULT NULL,
  `depo_amt` decimal(7,2) DEFAULT NULL,
  `ttl_exp_amt` decimal(7,2) DEFAULT NULL,
  `ttl_sales_exp_amt` decimal(7,2) DEFAULT NULL,
  `fr_store_daily_cash_id` int(5) DEFAULT NULL,
  `empl_id` int(5) DEFAULT NULL,
  `event_id` int(5) DEFAULT NULL,
  `short_excess_amt` decimal(7,2) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Store Daily Cash Header';

-- --------------------------------------------------------

--
-- Table structure for table `store_daily_cash_dtls`
--

CREATE TABLE IF NOT EXISTS `store_daily_cash_dtls` (
  `store_daily_cash_dtl_id` int(5) unsigned NOT NULL,
  `store_daily_cash_id` int(5) DEFAULT NULL,
  `denomination` decimal(7,2) DEFAULT NULL,
  `denomination_qty` int(5) DEFAULT NULL,
  `cash_amount` decimal(7,2) DEFAULT NULL,
  `return_denomination_qty` int(5) DEFAULT NULL,
  `return_amount` decimal(7,2) DEFAULT NULL,
  `created_by` int(5) DEFAULT NULL,
  `created_date` datetime DEFAULT NULL,
  `updated_by` int(5) DEFAULT NULL,
  `updated_date` datetime DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Store Daily Cash Details';

-- --------------------------------------------------------

--
-- Table structure for table `store_loc`
--

CREATE TABLE IF NOT EXISTS `store_loc` (
  `store_loc_id` int(5) unsigned NOT NULL,
  `store_loc` varchar(100) COLLATE utf8_bin NOT NULL DEFAULT '',
  `loc_id` int(5) DEFAULT NULL,
  `store_id` int(5) DEFAULT NULL,
  `is_cart` int(5) NOT NULL DEFAULT '0',
  `active` int(5) NOT NULL DEFAULT '1',
  `created_by` int(5) DEFAULT NULL,
  `created_date` datetime DEFAULT NULL,
  `updated_by` int(5) DEFAULT NULL,
  `updated_date` datetime DEFAULT NULL,
  `last_posted_dcash` int(11) DEFAULT NULL,
  `last_posted_dsales` int(11) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Store locations';

-- --------------------------------------------------------

--
-- Table structure for table `store_loc_exp`
--

CREATE TABLE IF NOT EXISTS `store_loc_exp` (
  `store_loc_exp_id` int(5) unsigned NOT NULL,
  `store_loc_id` int(5) DEFAULT NULL,
  `exp_date` datetime DEFAULT NULL,
  `posted` int(5) NOT NULL DEFAULT '0',
  `created_by` int(5) DEFAULT NULL,
  `created_date` datetime DEFAULT NULL,
  `updated_by` int(5) DEFAULT NULL,
  `updated_date` datetime DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Store Location Expenses';

-- --------------------------------------------------------

--
-- Table structure for table `store_loc_exp_dtls`
--

CREATE TABLE IF NOT EXISTS `store_loc_exp_dtls` (
  `store_loc_exp_dtl_id` int(5) unsigned NOT NULL,
  `store_loc_exp_id` int(5) DEFAULT NULL,
  `exp_desc` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `exp_amt` decimal(7,2) DEFAULT NULL,
  `created_by` int(5) DEFAULT NULL,
  `created_date` datetime DEFAULT NULL,
  `updated_by` int(5) DEFAULT NULL,
  `updated_date` datetime DEFAULT NULL,
  `or_no` varchar(20) COLLATE utf8_bin DEFAULT NULL,
  `fr_sales` int(1) DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Store Location Expense Details';

-- --------------------------------------------------------

--
-- Table structure for table `store_loc_supplies`
--

CREATE TABLE IF NOT EXISTS `store_loc_supplies` (
  `store_loc_supply_id` int(5) unsigned NOT NULL,
  `store_loc_id` int(5) DEFAULT NULL,
  `stock_daily_qty` decimal(5,2) DEFAULT NULL,
  `created_by` int(5) DEFAULT NULL,
  `created_date` datetime DEFAULT NULL,
  `updated_by` int(5) DEFAULT NULL,
  `updated_date` datetime DEFAULT NULL,
  `loc_supply_id` int(5) DEFAULT NULL,
  `prev_qty` decimal(7,2) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Store Location Supplies reference';

-- --------------------------------------------------------

--
-- Table structure for table `store_supplies`
--

CREATE TABLE IF NOT EXISTS `store_supplies` (
  `store_supply_id` int(5) unsigned NOT NULL,
  `store_id` int(5) DEFAULT NULL,
  `supply_id` int(5) DEFAULT NULL,
  `created_by` int(5) DEFAULT NULL,
  `created_date` datetime DEFAULT NULL,
  `updated_by` int(5) DEFAULT NULL,
  `updated_date` datetime DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Store supplies reference';

-- --------------------------------------------------------

--
-- Table structure for table `suppliers`
--

CREATE TABLE IF NOT EXISTS `suppliers` (
  `supplier_id` int(5) unsigned NOT NULL,
  `supplier_name` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `contact_name` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `contact_no` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `active` int(5) NOT NULL DEFAULT '1',
  `created_by` int(5) DEFAULT NULL,
  `created_date` datetime DEFAULT NULL,
  `updated_by` int(5) DEFAULT NULL,
  `updated_date` datetime DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='suppliers';

-- --------------------------------------------------------

--
-- Table structure for table `supplies`
--

CREATE TABLE IF NOT EXISTS `supplies` (
  `supply_id` int(5) unsigned NOT NULL,
  `supply_code` varchar(25) COLLATE utf8_bin DEFAULT NULL,
  `supply_desc` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `supply_type_id` int(5) DEFAULT NULL,
  `created_by` int(5) DEFAULT NULL,
  `created_date` datetime DEFAULT NULL,
  `updated_by` int(5) DEFAULT NULL,
  `updated_date` datetime DEFAULT NULL,
  `unit_id` int(5) DEFAULT NULL,
  `supply_srp` decimal(7,2) DEFAULT NULL,
  `seq_no` int(5) DEFAULT NULL,
  `weight_serve` decimal(7,2) DEFAULT NULL,
  `supply_cost` decimal(7,2) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='supplies';

-- --------------------------------------------------------

--
-- Table structure for table `supply_brands`
--

CREATE TABLE IF NOT EXISTS `supply_brands` (
  `supply_brand_id` int(5) unsigned NOT NULL,
  `brand_id` int(5) DEFAULT NULL,
  `supply_id` int(5) DEFAULT NULL,
  `conv_id` int(5) DEFAULT NULL,
  `supply_cost` decimal(7,2) DEFAULT NULL,
  `created_by` int(5) DEFAULT NULL,
  `created_date` datetime DEFAULT NULL,
  `updated_by` int(5) DEFAULT NULL,
  `updated_date` datetime DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Supply Brands';

-- --------------------------------------------------------

--
-- Table structure for table `supply_is`
--

CREATE TABLE IF NOT EXISTS `supply_is` (
  `supply_is_id` int(5) unsigned NOT NULL,
  `is_no` varchar(10) COLLATE utf8_bin DEFAULT NULL,
  `is_date` datetime DEFAULT NULL,
  `store_loc_id` int(5) DEFAULT NULL,
  `posted` int(5) NOT NULL DEFAULT '0',
  `created_by` int(5) DEFAULT NULL,
  `created_date` datetime DEFAULT NULL,
  `updated_by` int(5) DEFAULT NULL,
  `updated_date` datetime DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Stock Issuance header to stores';

-- --------------------------------------------------------

--
-- Table structure for table `supply_is_dtls`
--

CREATE TABLE IF NOT EXISTS `supply_is_dtls` (
  `supply_is_dtl_id` int(5) unsigned NOT NULL,
  `supply_is_id` int(5) DEFAULT NULL,
  `supply_is_qty` decimal(7,2) DEFAULT NULL,
  `loc_supply_brand_id` int(5) DEFAULT NULL,
  `created_by` int(5) DEFAULT NULL,
  `created_date` datetime DEFAULT NULL,
  `updated_by` int(5) DEFAULT NULL,
  `updated_date` datetime DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Stock Issuance details to stores';

-- --------------------------------------------------------

--
-- Table structure for table `supply_types`
--

CREATE TABLE IF NOT EXISTS `supply_types` (
  `supply_type_id` int(5) unsigned NOT NULL,
  `supply_type` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `created_by` int(5) DEFAULT NULL,
  `created_date` datetime DEFAULT NULL,
  `updated_by` int(5) DEFAULT NULL,
  `updated_date` datetime DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Types of Supply';

-- --------------------------------------------------------

--
-- Table structure for table `systems`
--

CREATE TABLE IF NOT EXISTS `systems` (
  `system_id` int(5) unsigned NOT NULL,
  `system_name` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `system_desc` varchar(100) COLLATE utf8_bin NOT NULL DEFAULT '',
  `created_by` int(5) DEFAULT NULL,
  `created_date` datetime DEFAULT NULL,
  `updated_by` int(5) DEFAULT NULL,
  `updated_date` datetime DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Systems';

-- --------------------------------------------------------

--
-- Table structure for table `units`
--

CREATE TABLE IF NOT EXISTS `units` (
  `unit_id` int(5) unsigned NOT NULL,
  `unit_sdesc` varchar(10) COLLATE utf8_bin NOT NULL DEFAULT '',
  `unit_desc` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `created_by` int(5) DEFAULT NULL,
  `created_date` datetime DEFAULT NULL,
  `updated_by` int(5) DEFAULT NULL,
  `updated_date` datetime DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Unit of Measures';

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `user_id` int(5) unsigned NOT NULL,
  `user_password` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `user_name` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `empl_id` int(5) DEFAULT NULL,
  `role_id` int(5) DEFAULT NULL,
  `active` int(5) NOT NULL DEFAULT '1',
  `created_by` int(5) DEFAULT NULL,
  `created_date` datetime DEFAULT NULL,
  `updated_by` int(5) DEFAULT NULL,
  `updated_date` datetime DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Users';

-- --------------------------------------------------------

--
-- Table structure for table `user_locations`
--

CREATE TABLE IF NOT EXISTS `user_locations` (
  `user_loc_id` int(5) unsigned NOT NULL,
  `user_id` int(5) DEFAULT NULL,
  `loc_id` int(5) DEFAULT NULL,
  `created_by` int(5) DEFAULT NULL,
  `created_date` datetime DEFAULT NULL,
  `updated_by` int(5) DEFAULT NULL,
  `updated_date` datetime DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='User Locations Access';

--
-- Indexes for dumped tables
--

--
-- Indexes for table `adjustments_ref`
--
ALTER TABLE `adjustments_ref`
  ADD PRIMARY KEY (`adjmt_id`),
  ADD UNIQUE KEY `adjustments_ref_uk` (`adjmt_desc`);

--
-- Indexes for table `bank_ref`
--
ALTER TABLE `bank_ref`
  ADD PRIMARY KEY (`bank_ref_id`),
  ADD UNIQUE KEY `bank_ref_pk_uk` (`bank_acctno`);

--
-- Indexes for table `brands`
--
ALTER TABLE `brands`
  ADD PRIMARY KEY (`brand_id`),
  ADD UNIQUE KEY `brands_uk` (`brand_name`);

--
-- Indexes for table `console_logs`
--
ALTER TABLE `console_logs`
  ADD PRIMARY KEY (`console_log_id`);

--
-- Indexes for table `conv_units`
--
ALTER TABLE `conv_units`
  ADD PRIMARY KEY (`conv_id`),
  ADD UNIQUE KEY `conv_units_uk` (`from_unit_id`,`conv_unit_id`,`conv_unit_qty`);

--
-- Indexes for table `dbstructures`
--
ALTER TABLE `dbstructures`
  ADD PRIMARY KEY (`dbstruct_id`);

--
-- Indexes for table `deductions_ref`
--
ALTER TABLE `deductions_ref`
  ADD PRIMARY KEY (`deduction_ref_id`),
  ADD UNIQUE KEY `deductions_ref_uk` (`deduction_code`);

--
-- Indexes for table `denomination_ref`
--
ALTER TABLE `denomination_ref`
  ADD PRIMARY KEY (`denomination`);

--
-- Indexes for table `employees`
--
ALTER TABLE `employees`
  ADD PRIMARY KEY (`empl_id`),
  ADD UNIQUE KEY `employees_name` (`empl_name`),
  ADD UNIQUE KEY `employees_idno` (`empl_idno`);

--
-- Indexes for table `events`
--
ALTER TABLE `events`
  ADD PRIMARY KEY (`event_id`),
  ADD UNIQUE KEY `events_uk` (`event_desc`);

--
-- Indexes for table `inv_summ`
--
ALTER TABLE `inv_summ`
  ADD PRIMARY KEY (`inv_summ_id`),
  ADD UNIQUE KEY `inv_summ_uk` (`inv_summ_year`,`inv_summ_month`,`loc_id`,`supply_id`);

--
-- Indexes for table `javascripts`
--
ALTER TABLE `javascripts`
  ADD PRIMARY KEY (`js_id`);

--
-- Indexes for table `locations`
--
ALTER TABLE `locations`
  ADD PRIMARY KEY (`loc_id`),
  ADD UNIQUE KEY `locations_uk` (`location`);

--
-- Indexes for table `loc_pc`
--
ALTER TABLE `loc_pc`
  ADD PRIMARY KEY (`loc_pc_id`),
  ADD UNIQUE KEY `loc_pc_uk` (`pc_no`,`loc_id`,`store_loc_id`);

--
-- Indexes for table `loc_pc_dtls`
--
ALTER TABLE `loc_pc_dtls`
  ADD PRIMARY KEY (`loc_pc_dtl_id`),
  ADD UNIQUE KEY `loc_pc_dtls_uk` (`loc_pc_id`,`loc_supply_brand_id`,`store_loc_supply_id`);

--
-- Indexes for table `loc_supplies`
--
ALTER TABLE `loc_supplies`
  ADD PRIMARY KEY (`loc_supply_id`),
  ADD UNIQUE KEY `loc_supplies_uk` (`loc_id`,`supply_id`);

--
-- Indexes for table `loc_supply_brands`
--
ALTER TABLE `loc_supply_brands`
  ADD PRIMARY KEY (`loc_supply_brand_id`),
  ADD UNIQUE KEY `loc_supply_brands_uk` (`loc_supply_id`,`supply_brand_id`);

--
-- Indexes for table `menu`
--
ALTER TABLE `menu`
  ADD PRIMARY KEY (`menu_id`),
  ADD UNIQUE KEY `menu_uk` (`menu_name`);

--
-- Indexes for table `menu_types`
--
ALTER TABLE `menu_types`
  ADD PRIMARY KEY (`menu_type_id`),
  ADD UNIQUE KEY `menu_types_uk` (`menu_type`);

--
-- Indexes for table `months`
--
ALTER TABLE `months`
  ADD PRIMARY KEY (`month_id`);

--
-- Indexes for table `page_templates`
--
ALTER TABLE `page_templates`
  ADD PRIMARY KEY (`page_template_id`);

--
-- Indexes for table `po`
--
ALTER TABLE `po`
  ADD PRIMARY KEY (`po_id`),
  ADD UNIQUE KEY `receiving_uk` (`po_no`,`loc_id`,`supplier_id`);

--
-- Indexes for table `positions`
--
ALTER TABLE `positions`
  ADD PRIMARY KEY (`position_id`),
  ADD UNIQUE KEY `positions_uk` (`position_desc`);

--
-- Indexes for table `po_dtls`
--
ALTER TABLE `po_dtls`
  ADD PRIMARY KEY (`po_dtl_id`),
  ADD UNIQUE KEY `po_dtls_uk` (`po_id`,`loc_supply_id`);

--
-- Indexes for table `receiving`
--
ALTER TABLE `receiving`
  ADD PRIMARY KEY (`receiving_id`),
  ADD UNIQUE KEY `receiving_uk` (`dr_no`,`po_id`);

--
-- Indexes for table `receiving_dtls`
--
ALTER TABLE `receiving_dtls`
  ADD PRIMARY KEY (`receiving_dtl_id`),
  ADD UNIQUE KEY `receiving_dtls_uk` (`receiving_id`,`po_dtl_id`);

--
-- Indexes for table `revision_logs`
--
ALTER TABLE `revision_logs`
  ADD PRIMARY KEY (`revision_id`);

--
-- Indexes for table `roles`
--
ALTER TABLE `roles`
  ADD PRIMARY KEY (`role_id`),
  ADD UNIQUE KEY `roles_uk` (`role_desc`);

--
-- Indexes for table `role_menus`
--
ALTER TABLE `role_menus`
  ADD PRIMARY KEY (`role_menu_id`),
  ADD UNIQUE KEY `role_menus_uk` (`role_id`,`menu_id`);

--
-- Indexes for table `role_procs`
--
ALTER TABLE `role_procs`
  ADD PRIMARY KEY (`role_proc_id`),
  ADD UNIQUE KEY `role_procs_uk` (`role_id`,`proc_id`);

--
-- Indexes for table `sales_summ`
--
ALTER TABLE `sales_summ`
  ADD PRIMARY KEY (`sales_summ_id`),
  ADD UNIQUE KEY `sales_summ_uk` (`sales_summ_year`,`sales_summ_month`,`store_loc_id`);

--
-- Indexes for table `sales_supply_summ`
--
ALTER TABLE `sales_supply_summ`
  ADD PRIMARY KEY (`sales_supply_id`),
  ADD UNIQUE KEY `sales_supply_uk` (`sales_supply_year`,`sales_supply_month`,`store_loc_id`,`supply_id`);

--
-- Indexes for table `select_options`
--
ALTER TABLE `select_options`
  ADD PRIMARY KEY (`select_id`);

--
-- Indexes for table `stock_adjustments`
--
ALTER TABLE `stock_adjustments`
  ADD PRIMARY KEY (`stock_adjmt_id`),
  ADD UNIQUE KEY `stock_adjustments_uk` (`stock_adjmt_no`);

--
-- Indexes for table `stock_transfer`
--
ALTER TABLE `stock_transfer`
  ADD PRIMARY KEY (`st_id`),
  ADD UNIQUE KEY `stock_transfer_uk` (`st_no`,`loc_id`);

--
-- Indexes for table `stock_transfer_dtls`
--
ALTER TABLE `stock_transfer_dtls`
  ADD PRIMARY KEY (`st_dtl_id`),
  ADD UNIQUE KEY `stock_transfer_dtls_uk` (`st_id`,`loc_supply_brand_id`);

--
-- Indexes for table `stores`
--
ALTER TABLE `stores`
  ADD PRIMARY KEY (`store_id`),
  ADD UNIQUE KEY `stores_uk` (`store_name`);

--
-- Indexes for table `store_bank_depo`
--
ALTER TABLE `store_bank_depo`
  ADD PRIMARY KEY (`store_bank_depo_id`),
  ADD UNIQUE KEY `store_bank_depo_uk` (`store_loc_id`,`sales_date`);

--
-- Indexes for table `store_bank_depo_dtls`
--
ALTER TABLE `store_bank_depo_dtls`
  ADD PRIMARY KEY (`store_bank_depo_dtl_id`),
  ADD UNIQUE KEY `store_bank_depo_dtls_uk` (`store_bank_depo_id`,`bank_ref_id`);

--
-- Indexes for table `store_bank_depo_summ`
--
ALTER TABLE `store_bank_depo_summ`
  ADD PRIMARY KEY (`bank_depo_summ_id`),
  ADD UNIQUE KEY `bank_depo_summ_uk` (`bank_depo_summ_year`,`bank_depo_summ_month`,`bank_ref_id`,`store_loc_id`);

--
-- Indexes for table `store_bank_wd`
--
ALTER TABLE `store_bank_wd`
  ADD PRIMARY KEY (`store_bank_wd_id`),
  ADD UNIQUE KEY `store_bank_wd_uk` (`store_loc_id`,`bank_ref_id`,`wd_date`);

--
-- Indexes for table `store_bank_wd_summ`
--
ALTER TABLE `store_bank_wd_summ`
  ADD PRIMARY KEY (`bank_wd_summ_id`),
  ADD UNIQUE KEY `bank_wd_summ_uk` (`bank_wd_summ_year`,`bank_wd_summ_month`,`bank_ref_id`,`store_loc_id`);

--
-- Indexes for table `store_daily_cash`
--
ALTER TABLE `store_daily_cash`
  ADD PRIMARY KEY (`store_daily_cash_id`),
  ADD UNIQUE KEY `store_daily_cash_uk` (`store_loc_id`,`tran_date`);

--
-- Indexes for table `store_daily_cash_dtls`
--
ALTER TABLE `store_daily_cash_dtls`
  ADD PRIMARY KEY (`store_daily_cash_dtl_id`),
  ADD UNIQUE KEY `store_daily_cash_dtls_uk` (`store_daily_cash_id`,`denomination`);

--
-- Indexes for table `store_loc`
--
ALTER TABLE `store_loc`
  ADD PRIMARY KEY (`store_loc_id`),
  ADD UNIQUE KEY `store_loc_uk` (`loc_id`,`store_id`,`store_loc`);

--
-- Indexes for table `store_loc_exp`
--
ALTER TABLE `store_loc_exp`
  ADD PRIMARY KEY (`store_loc_exp_id`),
  ADD UNIQUE KEY `store_loc_exp_uk` (`exp_date`,`store_loc_id`);

--
-- Indexes for table `store_loc_exp_dtls`
--
ALTER TABLE `store_loc_exp_dtls`
  ADD PRIMARY KEY (`store_loc_exp_dtl_id`),
  ADD UNIQUE KEY `store_loc_exp_dtls_uk` (`store_loc_exp_id`,`exp_desc`);

--
-- Indexes for table `store_loc_supplies`
--
ALTER TABLE `store_loc_supplies`
  ADD PRIMARY KEY (`store_loc_supply_id`),
  ADD UNIQUE KEY `store_loc_supplies_uk` (`store_loc_id`,`loc_supply_id`);

--
-- Indexes for table `store_supplies`
--
ALTER TABLE `store_supplies`
  ADD PRIMARY KEY (`store_supply_id`),
  ADD UNIQUE KEY `store_supplies_uk` (`store_id`,`supply_id`);

--
-- Indexes for table `suppliers`
--
ALTER TABLE `suppliers`
  ADD PRIMARY KEY (`supplier_id`),
  ADD UNIQUE KEY `suppliers_uk` (`supplier_name`);

--
-- Indexes for table `supplies`
--
ALTER TABLE `supplies`
  ADD PRIMARY KEY (`supply_id`),
  ADD UNIQUE KEY `supplies_uk` (`supply_code`);

--
-- Indexes for table `supply_brands`
--
ALTER TABLE `supply_brands`
  ADD PRIMARY KEY (`supply_brand_id`),
  ADD UNIQUE KEY `supply_brands_uk` (`brand_id`,`supply_id`,`conv_id`);

--
-- Indexes for table `supply_is`
--
ALTER TABLE `supply_is`
  ADD PRIMARY KEY (`supply_is_id`),
  ADD UNIQUE KEY `supply_is_uk` (`is_no`,`store_loc_id`);

--
-- Indexes for table `supply_is_dtls`
--
ALTER TABLE `supply_is_dtls`
  ADD PRIMARY KEY (`supply_is_dtl_id`),
  ADD UNIQUE KEY `supply_is_dtls_uk` (`supply_is_id`,`loc_supply_brand_id`);

--
-- Indexes for table `supply_types`
--
ALTER TABLE `supply_types`
  ADD PRIMARY KEY (`supply_type_id`),
  ADD UNIQUE KEY `supply_types_uk` (`supply_type`);

--
-- Indexes for table `systems`
--
ALTER TABLE `systems`
  ADD PRIMARY KEY (`system_id`),
  ADD UNIQUE KEY `systems_uk` (`system_name`);

--
-- Indexes for table `units`
--
ALTER TABLE `units`
  ADD PRIMARY KEY (`unit_id`),
  ADD UNIQUE KEY `units_uk` (`unit_desc`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`),
  ADD UNIQUE KEY `users_uk` (`user_name`);

--
-- Indexes for table `user_locations`
--
ALTER TABLE `user_locations`
  ADD PRIMARY KEY (`user_loc_id`),
  ADD UNIQUE KEY `user_locations_uk` (`user_id`,`loc_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `adjustments_ref`
--
ALTER TABLE `adjustments_ref`
  MODIFY `adjmt_id` int(5) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `bank_ref`
--
ALTER TABLE `bank_ref`
  MODIFY `bank_ref_id` int(5) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `brands`
--
ALTER TABLE `brands`
  MODIFY `brand_id` int(5) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `console_logs`
--
ALTER TABLE `console_logs`
  MODIFY `console_log_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `conv_units`
--
ALTER TABLE `conv_units`
  MODIFY `conv_id` int(5) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `dbstructures`
--
ALTER TABLE `dbstructures`
  MODIFY `dbstruct_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `deductions_ref`
--
ALTER TABLE `deductions_ref`
  MODIFY `deduction_ref_id` int(5) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `employees`
--
ALTER TABLE `employees`
  MODIFY `empl_id` int(5) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `events`
--
ALTER TABLE `events`
  MODIFY `event_id` int(5) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `inv_summ`
--
ALTER TABLE `inv_summ`
  MODIFY `inv_summ_id` int(5) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `javascripts`
--
ALTER TABLE `javascripts`
  MODIFY `js_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `locations`
--
ALTER TABLE `locations`
  MODIFY `loc_id` int(5) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `loc_pc`
--
ALTER TABLE `loc_pc`
  MODIFY `loc_pc_id` int(5) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `loc_pc_dtls`
--
ALTER TABLE `loc_pc_dtls`
  MODIFY `loc_pc_dtl_id` int(5) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `loc_supplies`
--
ALTER TABLE `loc_supplies`
  MODIFY `loc_supply_id` int(5) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `loc_supply_brands`
--
ALTER TABLE `loc_supply_brands`
  MODIFY `loc_supply_brand_id` int(5) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `menu`
--
ALTER TABLE `menu`
  MODIFY `menu_id` int(5) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `menu_types`
--
ALTER TABLE `menu_types`
  MODIFY `menu_type_id` int(5) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `page_templates`
--
ALTER TABLE `page_templates`
  MODIFY `page_template_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `po`
--
ALTER TABLE `po`
  MODIFY `po_id` int(5) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `positions`
--
ALTER TABLE `positions`
  MODIFY `position_id` int(5) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `po_dtls`
--
ALTER TABLE `po_dtls`
  MODIFY `po_dtl_id` int(5) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `receiving`
--
ALTER TABLE `receiving`
  MODIFY `receiving_id` int(5) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `receiving_dtls`
--
ALTER TABLE `receiving_dtls`
  MODIFY `receiving_dtl_id` int(5) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `revision_logs`
--
ALTER TABLE `revision_logs`
  MODIFY `revision_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `roles`
--
ALTER TABLE `roles`
  MODIFY `role_id` int(5) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `role_menus`
--
ALTER TABLE `role_menus`
  MODIFY `role_menu_id` int(5) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `role_procs`
--
ALTER TABLE `role_procs`
  MODIFY `role_proc_id` int(5) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `sales_summ`
--
ALTER TABLE `sales_summ`
  MODIFY `sales_summ_id` int(5) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `sales_supply_summ`
--
ALTER TABLE `sales_supply_summ`
  MODIFY `sales_supply_id` int(5) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `select_options`
--
ALTER TABLE `select_options`
  MODIFY `select_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `stock_adjustments`
--
ALTER TABLE `stock_adjustments`
  MODIFY `stock_adjmt_id` int(5) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `stock_transfer`
--
ALTER TABLE `stock_transfer`
  MODIFY `st_id` int(5) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `stock_transfer_dtls`
--
ALTER TABLE `stock_transfer_dtls`
  MODIFY `st_dtl_id` int(5) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `stores`
--
ALTER TABLE `stores`
  MODIFY `store_id` int(5) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `store_bank_depo`
--
ALTER TABLE `store_bank_depo`
  MODIFY `store_bank_depo_id` int(5) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `store_bank_depo_dtls`
--
ALTER TABLE `store_bank_depo_dtls`
  MODIFY `store_bank_depo_dtl_id` int(5) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `store_bank_depo_summ`
--
ALTER TABLE `store_bank_depo_summ`
  MODIFY `bank_depo_summ_id` int(5) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `store_bank_wd`
--
ALTER TABLE `store_bank_wd`
  MODIFY `store_bank_wd_id` int(5) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `store_bank_wd_summ`
--
ALTER TABLE `store_bank_wd_summ`
  MODIFY `bank_wd_summ_id` int(5) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `store_daily_cash`
--
ALTER TABLE `store_daily_cash`
  MODIFY `store_daily_cash_id` int(5) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `store_daily_cash_dtls`
--
ALTER TABLE `store_daily_cash_dtls`
  MODIFY `store_daily_cash_dtl_id` int(5) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `store_loc`
--
ALTER TABLE `store_loc`
  MODIFY `store_loc_id` int(5) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `store_loc_exp`
--
ALTER TABLE `store_loc_exp`
  MODIFY `store_loc_exp_id` int(5) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `store_loc_exp_dtls`
--
ALTER TABLE `store_loc_exp_dtls`
  MODIFY `store_loc_exp_dtl_id` int(5) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `store_loc_supplies`
--
ALTER TABLE `store_loc_supplies`
  MODIFY `store_loc_supply_id` int(5) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `store_supplies`
--
ALTER TABLE `store_supplies`
  MODIFY `store_supply_id` int(5) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `suppliers`
--
ALTER TABLE `suppliers`
  MODIFY `supplier_id` int(5) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `supplies`
--
ALTER TABLE `supplies`
  MODIFY `supply_id` int(5) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `supply_brands`
--
ALTER TABLE `supply_brands`
  MODIFY `supply_brand_id` int(5) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `supply_is`
--
ALTER TABLE `supply_is`
  MODIFY `supply_is_id` int(5) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `supply_is_dtls`
--
ALTER TABLE `supply_is_dtls`
  MODIFY `supply_is_dtl_id` int(5) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `supply_types`
--
ALTER TABLE `supply_types`
  MODIFY `supply_type_id` int(5) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `systems`
--
ALTER TABLE `systems`
  MODIFY `system_id` int(5) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `units`
--
ALTER TABLE `units`
  MODIFY `unit_id` int(5) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int(5) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `user_locations`
--
ALTER TABLE `user_locations`
  MODIFY `user_loc_id` int(5) unsigned NOT NULL AUTO_INCREMENT;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
